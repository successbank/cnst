/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: project5_db
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '배너 제목',
  `subtitle` text DEFAULT NULL COMMENT '배너 부제목',
  `image_path` varchar(500) DEFAULT NULL COMMENT '이미지 경로',
  `link_url` varchar(500) DEFAULT NULL COMMENT '링크 URL',
  `link_target` varchar(20) DEFAULT '_self' COMMENT '링크 타겟 (_self, _blank)',
  `display_order` int(11) DEFAULT 0 COMMENT '표시 순서',
  `is_active` tinyint(4) DEFAULT 1 COMMENT '활성화 여부 (1: 활성, 0: 비활성)',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_display_order` (`display_order`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='배너 관리 테이블';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES
(3,'메인 페이지에','메인 페이지에메인 페이지에메인 페이지에메인 페이지에','banner_1756604076_68b3a6ac908d8.png','','_blank',0,1,'2025-08-31 01:34:36','2025-08-31 02:22:45'),
(4,'메인 페이지에메인 페이지에메인 페이지에','메인 페이지에','banner_1756604108_68b3a6cc8e771.png','','_self',1,1,'2025-08-31 01:35:08','2025-08-31 02:22:45');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_comments`
--

DROP TABLE IF EXISTS `board_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `board_type` varchar(50) NOT NULL,
  `board_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_comments`
--

LOCK TABLES `board_comments` WRITE;
/*!40000 ALTER TABLE `board_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_consignment`
--

DROP TABLE IF EXISTS `board_consignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_consignment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `attachment` text DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stock_quantity` varchar(100) DEFAULT NULL,
  `price_info` varchar(255) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `status` enum('active','sold','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_consignment`
--

LOCK TABLES `board_consignment` WRITE;
/*!40000 ALTER TABLE `board_consignment` DISABLE KEYS */;
INSERT INTO `board_consignment` VALUES
(1,'test','asdfsaf','테스트333','1212','성공은행','강널말뚝','[\"1756184277_Panamera Turbo S E-Hybrid (3).jpeg\",\"1756184277_Panamera Turbo S E-Hybrid (2).jpeg\",\"1756184277_Panamera Turbo S E-Hybrid (8).jpeg\",\"1756184277_Panamera Turbo S E-Hybrid (4).jpeg\",\"1756184277_Panamera Turbo S E-Hybrid (6).jpeg\"]',0,'2025-08-26 04:57:57','2025-08-26 04:57:57','100','333','박현','','powernews74@gmail.com','ddddd',NULL,0,'active');
/*!40000 ALTER TABLE `board_consignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_news`
--

DROP TABLE IF EXISTS `board_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_news`
--

LOCK TABLES `board_news` WRITE;
/*!40000 ALTER TABLE `board_news` DISABLE KEYS */;
INSERT INTO `board_news` VALUES
(1,'철강 가격 동향 및 전망','최근 국제 철강 가격이 상승세를 보이고 있습니다.\n\n중국의 생산 감축과 원자재 가격 상승이 주요 원인으로 분석됩니다.','관리자','1234','한국철강신문',NULL,NULL,4,'2025-08-05 01:52:35','2025-08-10 06:07:11'),
(2,'친환경 철강 생산 기술 개발','포스코가 수소환원제철 기술 개발에 성공했다고 발표했습니다.\n\n이를 통해 탄소 배출을 획기적으로 줄일 수 있을 것으로 기대됩니다.','관리자','1234','철강업계뉴스',NULL,NULL,0,'2025-08-05 01:52:35','2025-08-05 01:52:35'),
(3,'testsddfd','sadfas','admin','','','',NULL,11,'2025-08-26 04:05:01','2025-08-30 23:49:38');
/*!40000 ALTER TABLE `board_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_notice`
--

DROP TABLE IF EXISTS `board_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `is_important` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_notice`
--

LOCK TABLES `board_notice` WRITE;
/*!40000 ALTER TABLE `board_notice` DISABLE KEYS */;
INSERT INTO `board_notice` VALUES
(1,'test','sdf','admin','',NULL,1,1,'2025-08-26 04:02:24','2025-08-26 04:02:44');
/*!40000 ALTER TABLE `board_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_quote`
--

DROP TABLE IF EXISTS `board_quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_quote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `company` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `attachment` text DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `is_answered` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `display_order` int(11) DEFAULT 0,
  `admin_reply` text DEFAULT NULL,
  `replied_at` datetime DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_quote`
--

LOCK TABLES `board_quote` WRITE;
/*!40000 ALTER TABLE `board_quote` DISABLE KEYS */;
INSERT INTO `board_quote` VALUES
(1,'sdf','dd','ssdf','1111','successbank','dev@successbank.co.kr','010-4147-9977','',0,0,'2025-08-26 04:18:12','2025-08-26 04:18:12',0,NULL,NULL,NULL),
(2,'ddddfdf','sdf','테스트333','1111','successbank','powernews74@gmail.com','010-4147-9977','1756182515_KakaoTalk_20250804_221050254.jpg',0,0,'2025-08-26 04:28:35','2025-08-26 04:28:35',0,NULL,NULL,NULL),
(3,'233424','fsdgdsfg','dsf','121212','successbank','dev@successbank.co.kr','010-4147-9977','1756182547_Panamera Turbo S E-Hybrid (3).jpeg',0,0,'2025-08-26 04:29:07','2025-08-26 04:40:38',0,NULL,NULL,NULL),
(4,'hdf','fsfsd','ssdf','1111','successbank22','dev@successbank.co.kr','010-4147-9977','',0,0,'2025-08-26 04:41:49','2025-08-26 04:41:49',0,NULL,NULL,NULL),
(5,'test','sadfsaf','dddfsfd','1212','sdfaf','powernews74@gmail.com','010-4147-9977','[\"1756184009_Panamera Turbo S E-Hybrid (3).jpeg\",\"1756184009_Panamera Turbo S E-Hybrid (2).jpeg\",\"1756184009_Panamera Turbo S E-Hybrid (8).jpeg\",\"1756184009_Panamera Turbo S E-Hybrid (4).jpeg\",\"1756184009_Panamera Turbo S E-Hybrid (6).jpeg\"]',1,0,'2025-08-26 04:53:29','2025-08-26 04:53:36',0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `board_quote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calculation_logs`
--

DROP TABLE IF EXISTS `calculation_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calculation_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_code` varchar(50) NOT NULL,
  `specification` varchar(100) DEFAULT NULL,
  `material` varchar(50) DEFAULT NULL,
  `length` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `calculated_weight` decimal(10,2) DEFAULT NULL,
  `user_ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calculation_logs`
--

LOCK TABLES `calculation_logs` WRITE;
/*!40000 ALTER TABLE `calculation_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `calculation_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `click_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_code` (`category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
INSERT INTO `product_categories` VALUES
(1,'rebar','철근',1,1,194,'2025-08-05 02:38:24'),
(2,'h-beam','H형강',2,1,165,'2025-08-05 02:38:24'),
(3,'steel-plate','철강(강판)',3,1,57,'2025-08-05 02:38:24'),
(4,'metal-lath','메탈라스',4,1,12,'2025-08-05 02:38:24'),
(5,'light-h-beam','경량H형강',5,1,82,'2025-08-05 02:38:24'),
(6,'i-beam','I형강',6,1,13,'2025-08-05 02:38:24'),
(7,'angle','ㄱ형강(앵글)',7,1,86,'2025-08-05 02:38:24'),
(8,'channel','ㄷ형강(찬넬)',8,1,7,'2025-08-05 02:38:24'),
(9,'round-bar','환봉',9,1,57,'2025-08-05 02:38:24'),
(10,'flat-bar','평철',10,1,6,'2025-08-05 02:38:24'),
(11,'c-beam','C형강',11,1,24,'2025-08-05 02:38:24'),
(12,'deck-plate','테크플레이트',12,1,122,'2025-08-05 02:38:24'),
(13,'square-pipe','사각파이프',13,1,30,'2025-08-05 02:38:24'),
(14,'round-pipe','원형파이프',14,1,6,'2025-08-05 02:38:24'),
(15,'rail','레일',15,1,75,'2025-08-05 02:38:24'),
(16,'sheet-pile','강널말뚝',16,1,61,'2025-08-05 02:38:24'),
(17,'stainless','스테인레스',17,1,18,'2025-08-05 02:38:24'),
(18,'unequal-angle','부등변ㄱ형강',21,1,3,'2025-08-31 06:24:40'),
(19,'bs-pipe','BS파이프',22,1,1,'2025-08-31 06:24:40'),
(20,'ks-pipe','KS파이프',23,1,1,'2025-08-31 06:24:40'),
(21,'structural-pipe','구조관',24,1,1,'2025-08-31 06:24:40'),
(22,'steel-pipe-pile','강관파일',25,1,1,'2025-08-31 06:24:40'),
(23,'temporary-deck','복공판',26,1,1,'2025-08-31 06:24:40'),
(24,'pressure-pipe','압력배관',28,1,1,'2025-08-31 06:24:40'),
(25,'conduit-pipe','전선관',29,1,1,'2025-08-31 06:24:40'),
(26,'scaffold-pipe','단관비계',30,1,1,'2025-08-31 06:24:40');
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `image_type` enum('main','detail','spec') DEFAULT 'detail',
  `display_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_specifications`
--

DROP TABLE IF EXISTS `product_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_specifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_code` varchar(50) NOT NULL,
  `specification` varchar(100) NOT NULL COMMENT '규격 (예: 25*25*3T)',
  `unit_weight` decimal(10,3) NOT NULL COMMENT '단위중량 (kg)',
  `material` varchar(50) DEFAULT NULL COMMENT '재질',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `idx_category` (`category_code`),
  KEY `idx_spec` (`specification`),
  KEY `idx_material` (`material`),
  CONSTRAINT `product_specifications_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_specifications`
--

LOCK TABLES `product_specifications` WRITE;
/*!40000 ALTER TABLE `product_specifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `specifications` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `min_order_qty` int(11) DEFAULT 1,
  `stock_status` enum('in_stock','out_of_stock','on_order') DEFAULT 'in_stock',
  `main_image` varchar(500) DEFAULT NULL,
  `detail_images` text DEFAULT NULL,
  `features` text DEFAULT NULL,
  `dimensions` text DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `material` varchar(200) DEFAULT NULL,
  `manufacturer` varchar(200) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `available_origins` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`available_origins`)),
  `delivery_info` text DEFAULT NULL,
  `quality_cert` varchar(500) DEFAULT NULL COMMENT '품질 인증',
  `product_features` text DEFAULT NULL COMMENT '제품 특징',
  `is_featured` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `view_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `calculation_type` enum('linear','sheet') DEFAULT 'linear' COMMENT '계산 유형: linear(선형), sheet(판재)',
  `unit_weight_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '규격별 단위중량 데이터' CHECK (json_valid(`unit_weight_data`)),
  `available_materials` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '사용 가능한 재질 목록' CHECK (json_valid(`available_materials`)),
  `available_sizes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '사용 가능한 규격 목록' CHECK (json_valid(`available_sizes`)),
  `has_calculator` tinyint(1) DEFAULT 0 COMMENT '계산기 사용 여부',
  `display_mode` enum('single','by_specification') DEFAULT 'single' COMMENT '표시 모드: single(단일), by_specification(규격별)',
  `parent_product_id` int(11) DEFAULT NULL COMMENT '부모 제품 ID (규격별 제품인 경우)',
  `specification` varchar(100) DEFAULT NULL COMMENT '개별 규격 (규격별 제품인 경우)',
  `specification_weight` decimal(10,3) DEFAULT NULL COMMENT '해당 규격의 단위중량',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `category_code` (`category_code`),
  KEY `idx_parent_product` (`parent_product_id`),
  KEY `idx_specification` (`specification`),
  CONSTRAINT `fk_parent_product` FOREIGN KEY (`parent_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_code`) REFERENCES `product_categories` (`category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=473 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(6,'flat-bar','평철',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:11:59','2025-08-31 13:36:37','linear','{\"13*3T\":{\"SS400\":0.306,\"SS400\\/A36\":0.306},\"16*3T\":{\"SS400\":0.377,\"SS400\\/A36\":0.377},\"16*4.5T\":{\"SS400\":0.565,\"SS400\\/A36\":0.565},\"19*3T\":{\"SS400\":0.448,\"SS400\\/A36\":0.448},\"19*4.5T\":{\"SS400\":0.671,\"SS400\\/A36\":0.671},\"19*6T\":{\"SS400\":0.895,\"SS400\\/A36\":0.895},\"22*3T\":{\"SS400\":0.518,\"SS400\\/A36\":0.518},\"22*4.5T\":{\"SS400\":0.777,\"SS400\\/A36\":0.777},\"22*6T\":{\"SS400\":1.04,\"SS400\\/A36\":1.04},\"25*3T\":{\"SS400\":0.589,\"SS400\\/A36\":0.589},\"25*4.5T\":{\"SS400\":0.883,\"SS400\\/A36\":0.883},\"25*6T\":{\"SS400\":1.18,\"SS400\\/A36\":1.18},\"25*9T\":{\"SS400\":1.77,\"SS400\\/A36\":1.77},\"25*12T\":{\"SS400\":2.36,\"SS400\\/A36\":2.36}}','[\"SS400\",\"SS400\\/A36\"]','[\"13*3T\",\"16*3T\",\"16*4.5T\",\"19*3T\",\"19*4.5T\",\"19*6T\",\"22*3T\",\"22*4.5T\",\"22*6T\",\"25*3T\",\"25*4.5T\",\"25*6T\",\"25*9T\",\"25*12T\"]',1,'by_specification',NULL,NULL,NULL),
(7,'round-bar','환봉',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:11:59','2025-08-31 13:36:37','linear','{\"RB 6\":{\"SS400\":0.222,\"SM45C\":0.222},\"RB 9\":{\"SS400\":0.499,\"SM45C\":0.499},\"RB 10\":{\"SS400\":0.617,\"SM45C\":0.617},\"RB 12\":{\"SS400\":0.888,\"SM45C\":0.888},\"RB 13\":{\"SS400\":1.04,\"SM45C\":1.04},\"RB 16\":{\"SS400\":1.58,\"SM45C\":1.58},\"RB 19\":{\"SS400\":2.23,\"SM45C\":2.23},\"RB 22\":{\"SS400\":2.98,\"SM45C\":2.98},\"RB 25\":{\"SS400\":3.85,\"SM45C\":3.85},\"RB 28\":{\"SS400\":4.83,\"SM45C\":4.83},\"RB 32\":{\"SS400\":6.31,\"SM45C\":6.31},\"RB 35\":{\"SS400\":7.55,\"SM45C\":7.55},\"RB 38\":{\"SS400\":8.9,\"SM45C\":8.9},\"RB 42\":{\"SS400\":10.9,\"SM45C\":10.9},\"RB 45\":{\"SS400\":12.5,\"SM45C\":12.5},\"RB 50\":{\"SS400\":15.4,\"SM45C\":15.4}}','[\"SS400\",\"SM45C\"]','[\"RB 6\",\"RB 9\",\"RB 10\",\"RB 12\",\"RB 13\",\"RB 16\",\"RB 19\",\"RB 22\",\"RB 25\",\"RB 28\",\"RB 32\",\"RB 35\",\"RB 38\",\"RB 42\",\"RB 45\",\"RB 50\"]',1,'by_specification',NULL,NULL,NULL),
(8,'steel-plate','HR철판',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:11:59','2025-08-31 13:36:37','sheet','{\"1.6T*3\'*6\'\":{\"SPHC\":22.7,\"SS400\":22.7},\"2.0T*3\'*6\'\":{\"SPHC\":28.4,\"SS400\":28.4},\"2.3T*3\'*6\'\":{\"SPHC\":32.6,\"SS400\":32.6},\"2.6T*3\'*6\'\":{\"SPHC\":36.8,\"SS400\":36.8},\"3.2T*3\'*6\'\":{\"SS400\":45.3},\"3.2T*4\'*8\'\":{\"SS400\":80.5},\"4.5T*3\'*6\'\":{\"SS400\":63.7},\"4.5T*4\'*8\'\":{\"SS400\":113.3},\"4.5T*5\'*10\'\":{\"SS400\":177.1},\"6.0T*3\'*6\'\":{\"SS400\":85},\"6.0T*4\'*8\'\":{\"SS400\":151.1},\"6.0T*5\'*10\'\":{\"SS400\":236.1},\"9.0T*3\'*6\'\":{\"SS400\":127.5},\"9.0T*4\'*8\'\":{\"SS400\":226.6},\"9.0T*5\'*10\'\":{\"SS400\":354.1},\"12T*3\'*6\'\":{\"SS400\":169.9},\"12T*4\'*8\'\":{\"SS400\":302.2},\"12T*5\'*10\'\":{\"SS400\":472.2}}','[\"SPHC\",\"SS400\"]','[\"1.6T*3\'*6\'\",\"2.0T*3\'*6\'\",\"2.3T*3\'*6\'\",\"2.6T*3\'*6\'\",\"3.2T*3\'*6\'\",\"3.2T*4\'*8\'\",\"4.5T*3\'*6\'\",\"4.5T*4\'*8\'\",\"4.5T*5\'*10\'\",\"6.0T*3\'*6\'\",\"6.0T*4\'*8\'\",\"6.0T*5\'*10\'\",\"9.0T*3\'*6\'\",\"9.0T*4\'*8\'\",\"9.0T*5\'*10\'\",\"12T*3\'*6\'\",\"12T*4\'*8\'\",\"12T*5\'*10\'\"]',1,'by_specification',NULL,NULL,NULL),
(9,'angle','ㄱ형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:11:59','2025-08-31 13:36:37','linear','{\"25*25*3T\":{\"SS400\":1.12},\"30*30*3T\":{\"SS400\":1.36},\"40*40*3T\":{\"SS400\":1.83},\"40*40*5T\":{\"SS400\":2.95},\"50*50*3T\":{\"SS400\":2.29},\"50*50*5T\":{\"SS400\":3.73},\"50*50*6T\":{\"SS400\":4.43},\"65*65*6T\":{\"SS400\":5.91},\"65*65*8T\":{\"SS400\":7.66},\"75*75*6T\":{\"SS400\":6.85},\"75*75*9T\":{\"SS400\":10},\"90*90*7T\":{\"SS400\":9.61},\"90*90*10T\":{\"SS400\":13.3},\"100*100*10T\":{\"SS400\":14.9},\"100*100*13T\":{\"SS400\":19.1}}','[\"SS400\"]','[\"25*25*3T\",\"30*30*3T\",\"40*40*3T\",\"40*40*5T\",\"50*50*3T\",\"50*50*5T\",\"50*50*6T\",\"65*65*6T\",\"65*65*8T\",\"75*75*6T\",\"75*75*9T\",\"90*90*7T\",\"90*90*10T\",\"100*100*10T\",\"100*100*13T\"]',1,'by_specification',NULL,NULL,NULL),
(10,'channel','ㄷ형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:11:59','2025-08-31 13:36:37','linear','{\"75*40*5*7\":{\"SS400\":6.92},\"100*50*5*7.5\":{\"SS400\":9.36},\"125*65*6*8\":{\"SS400\":13.4},\"150*75*6.5*10\":{\"SS400\":18.6},\"150*75*9*12.5\":{\"SS400\":24},\"180*75*7*10.5\":{\"SS400\":21.4},\"200*80*7.5*11\":{\"SS400\":24.6},\"200*90*8*13.5\":{\"SS400\":30.3},\"250*90*9*13\":{\"SS400\":34.6},\"250*90*11*14.5\":{\"SS400\":40.2},\"300*90*9*13\":{\"SS400\":38.1},\"300*90*10*15.5\":{\"SS400\":43.8},\"380*100*10.5*16\":{\"SS400\":54}}','[\"SS400\"]','[\"75*40*5*7\",\"100*50*5*7.5\",\"125*65*6*8\",\"150*75*6.5*10\",\"150*75*9*12.5\",\"180*75*7*10.5\",\"200*80*7.5*11\",\"200*90*8*13.5\",\"250*90*9*13\",\"250*90*11*14.5\",\"300*90*9*13\",\"300*90*10*15.5\",\"380*100*10.5*16\"]',1,'by_specification',NULL,NULL,NULL),
(11,'angle','ㄱ형강 25*25*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"25*25*3T\":{\"SS400\":1.12}}','[\"SS400\"]','[\"25*25*3T\"]',1,'single',9,'25*25*3T',1.120),
(12,'angle','ㄱ형강 30*30*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"30*30*3T\":{\"SS400\":1.36}}','[\"SS400\"]','[\"30*30*3T\"]',1,'single',9,'30*30*3T',1.360),
(13,'angle','ㄱ형강 40*40*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"40*40*3T\":{\"SS400\":1.83}}','[\"SS400\"]','[\"40*40*3T\"]',1,'single',9,'40*40*3T',1.830),
(14,'angle','ㄱ형강 40*40*5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"40*40*5T\":{\"SS400\":2.95}}','[\"SS400\"]','[\"40*40*5T\"]',1,'single',9,'40*40*5T',2.950),
(15,'angle','ㄱ형강 50*50*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"50*50*3T\":{\"SS400\":2.29}}','[\"SS400\"]','[\"50*50*3T\"]',1,'single',9,'50*50*3T',2.290),
(16,'angle','ㄱ형강 50*50*5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"50*50*5T\":{\"SS400\":3.73}}','[\"SS400\"]','[\"50*50*5T\"]',1,'single',9,'50*50*5T',3.730),
(17,'angle','ㄱ형강 50*50*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"50*50*6T\":{\"SS400\":4.43}}','[\"SS400\"]','[\"50*50*6T\"]',1,'single',9,'50*50*6T',4.430),
(18,'angle','ㄱ형강 65*65*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"65*65*6T\":{\"SS400\":5.91}}','[\"SS400\"]','[\"65*65*6T\"]',1,'single',9,'65*65*6T',5.910),
(19,'angle','ㄱ형강 65*65*8T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"65*65*8T\":{\"SS400\":7.66}}','[\"SS400\"]','[\"65*65*8T\"]',1,'single',9,'65*65*8T',7.660),
(20,'angle','ㄱ형강 75*75*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"75*75*6T\":{\"SS400\":6.85}}','[\"SS400\"]','[\"75*75*6T\"]',1,'single',9,'75*75*6T',6.850),
(21,'angle','ㄱ형강 75*75*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"75*75*9T\":{\"SS400\":10}}','[\"SS400\"]','[\"75*75*9T\"]',1,'single',9,'75*75*9T',10.000),
(22,'angle','ㄱ형강 90*90*7T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"90*90*7T\":{\"SS400\":9.61}}','[\"SS400\"]','[\"90*90*7T\"]',1,'single',9,'90*90*7T',9.610),
(23,'angle','ㄱ형강 90*90*10T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"90*90*10T\":{\"SS400\":13.3}}','[\"SS400\"]','[\"90*90*10T\"]',1,'single',9,'90*90*10T',13.300),
(24,'angle','ㄱ형강 100*100*10T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"100*100*10T\":{\"SS400\":14.9}}','[\"SS400\"]','[\"100*100*10T\"]',1,'single',9,'100*100*10T',14.900),
(25,'angle','ㄱ형강 100*100*13T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"100*100*13T\":{\"SS400\":19.1}}','[\"SS400\"]','[\"100*100*13T\"]',1,'single',9,'100*100*13T',19.100),
(26,'channel','ㄷ형강 75*40*5*7',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"75*40*5*7\":{\"SS400\":6.92}}','[\"SS400\"]','[\"75*40*5*7\"]',1,'single',10,'75*40*5*7',6.920),
(27,'channel','ㄷ형강 100*50*5*7.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"100*50*5*7.5\":{\"SS400\":9.36}}','[\"SS400\"]','[\"100*50*5*7.5\"]',1,'single',10,'100*50*5*7.5',9.360),
(28,'channel','ㄷ형강 125*65*6*8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"125*65*6*8\":{\"SS400\":13.4}}','[\"SS400\"]','[\"125*65*6*8\"]',1,'single',10,'125*65*6*8',13.400),
(29,'channel','ㄷ형강 150*75*6.5*10',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"150*75*6.5*10\":{\"SS400\":18.6}}','[\"SS400\"]','[\"150*75*6.5*10\"]',1,'single',10,'150*75*6.5*10',18.600),
(30,'channel','ㄷ형강 150*75*9*12.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"150*75*9*12.5\":{\"SS400\":24}}','[\"SS400\"]','[\"150*75*9*12.5\"]',1,'single',10,'150*75*9*12.5',24.000),
(31,'channel','ㄷ형강 180*75*7*10.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"180*75*7*10.5\":{\"SS400\":21.4}}','[\"SS400\"]','[\"180*75*7*10.5\"]',1,'single',10,'180*75*7*10.5',21.400),
(32,'channel','ㄷ형강 200*80*7.5*11',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"200*80*7.5*11\":{\"SS400\":24.6}}','[\"SS400\"]','[\"200*80*7.5*11\"]',1,'single',10,'200*80*7.5*11',24.600),
(33,'channel','ㄷ형강 200*90*8*13.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"200*90*8*13.5\":{\"SS400\":30.3}}','[\"SS400\"]','[\"200*90*8*13.5\"]',1,'single',10,'200*90*8*13.5',30.300),
(34,'channel','ㄷ형강 250*90*9*13',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"250*90*9*13\":{\"SS400\":34.6}}','[\"SS400\"]','[\"250*90*9*13\"]',1,'single',10,'250*90*9*13',34.600),
(35,'channel','ㄷ형강 250*90*11*14.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:00','2025-08-31 13:36:37','linear','{\"250*90*11*14.5\":{\"SS400\":40.2}}','[\"SS400\"]','[\"250*90*11*14.5\"]',1,'single',10,'250*90*11*14.5',40.200),
(36,'channel','ㄷ형강 300*90*9*13',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:17:01','2025-08-31 13:36:37','linear','{\"300*90*9*13\":{\"SS400\":38.1}}','[\"SS400\"]','[\"300*90*9*13\"]',1,'single',10,'300*90*9*13',38.100),
(37,'channel','ㄷ형강 300*90*10*15.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:01','2025-08-31 13:36:37','linear','{\"300*90*10*15.5\":{\"SS400\":43.8}}','[\"SS400\"]','[\"300*90*10*15.5\"]',1,'single',10,'300*90*10*15.5',43.800),
(38,'channel','ㄷ형강 380*100*10.5*16',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:17:01','2025-08-31 13:36:37','linear','{\"380*100*10.5*16\":{\"SS400\":54}}','[\"SS400\"]','[\"380*100*10.5*16\"]',1,'single',10,'380*100*10.5*16',54.000),
(39,'flat-bar','평철 13*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"13*3T\":{\"SS400\":0.306,\"SS400\\/A36\":0.306}}','[\"SS400\",\"SS400\\/A36\"]','[\"13*3T\"]',1,'single',6,'13*3T',0.306),
(40,'flat-bar','평철 16*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"16*3T\":{\"SS400\":0.377,\"SS400\\/A36\":0.377}}','[\"SS400\",\"SS400\\/A36\"]','[\"16*3T\"]',1,'single',6,'16*3T',0.377),
(41,'flat-bar','평철 16*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"16*4.5T\":{\"SS400\":0.565,\"SS400\\/A36\":0.565}}','[\"SS400\",\"SS400\\/A36\"]','[\"16*4.5T\"]',1,'single',6,'16*4.5T',0.565),
(42,'flat-bar','평철 19*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"19*3T\":{\"SS400\":0.448,\"SS400\\/A36\":0.448}}','[\"SS400\",\"SS400\\/A36\"]','[\"19*3T\"]',1,'single',6,'19*3T',0.448),
(43,'flat-bar','평철 19*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"19*4.5T\":{\"SS400\":0.671,\"SS400\\/A36\":0.671}}','[\"SS400\",\"SS400\\/A36\"]','[\"19*4.5T\"]',1,'single',6,'19*4.5T',0.671),
(44,'flat-bar','평철 19*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"19*6T\":{\"SS400\":0.895,\"SS400\\/A36\":0.895}}','[\"SS400\",\"SS400\\/A36\"]','[\"19*6T\"]',1,'single',6,'19*6T',0.895),
(45,'flat-bar','평철 22*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"22*3T\":{\"SS400\":0.518,\"SS400\\/A36\":0.518}}','[\"SS400\",\"SS400\\/A36\"]','[\"22*3T\"]',1,'single',6,'22*3T',0.518),
(46,'flat-bar','평철 22*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"22*4.5T\":{\"SS400\":0.777,\"SS400\\/A36\":0.777}}','[\"SS400\",\"SS400\\/A36\"]','[\"22*4.5T\"]',1,'single',6,'22*4.5T',0.777),
(47,'flat-bar','평철 22*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"22*6T\":{\"SS400\":1.04,\"SS400\\/A36\":1.04}}','[\"SS400\",\"SS400\\/A36\"]','[\"22*6T\"]',1,'single',6,'22*6T',1.040),
(48,'flat-bar','평철 25*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"25*3T\":{\"SS400\":0.589,\"SS400\\/A36\":0.589}}','[\"SS400\",\"SS400\\/A36\"]','[\"25*3T\"]',1,'single',6,'25*3T',0.589),
(49,'flat-bar','평철 25*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"25*4.5T\":{\"SS400\":0.883,\"SS400\\/A36\":0.883}}','[\"SS400\",\"SS400\\/A36\"]','[\"25*4.5T\"]',1,'single',6,'25*4.5T',0.883),
(50,'flat-bar','평철 25*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"25*6T\":{\"SS400\":1.18,\"SS400\\/A36\":1.18}}','[\"SS400\",\"SS400\\/A36\"]','[\"25*6T\"]',1,'single',6,'25*6T',1.180),
(51,'flat-bar','평철 25*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"25*9T\":{\"SS400\":1.77,\"SS400\\/A36\":1.77}}','[\"SS400\",\"SS400\\/A36\"]','[\"25*9T\"]',1,'single',6,'25*9T',1.770),
(52,'flat-bar','평철 25*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:04','2025-08-31 13:36:37','linear','{\"25*12T\":{\"SS400\":2.36,\"SS400\\/A36\":2.36}}','[\"SS400\",\"SS400\\/A36\"]','[\"25*12T\"]',1,'single',6,'25*12T',2.360),
(53,'round-bar','환봉 RB 6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 6\":{\"SS400\":0.222,\"SM45C\":0.222}}','[\"SS400\",\"SM45C\"]','[\"RB 6\"]',1,'single',7,'RB 6',0.222),
(54,'round-bar','환봉 RB 9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 9\":{\"SS400\":0.499,\"SM45C\":0.499}}','[\"SS400\",\"SM45C\"]','[\"RB 9\"]',1,'single',7,'RB 9',0.499),
(55,'round-bar','환봉 RB 10',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 10\":{\"SS400\":0.617,\"SM45C\":0.617}}','[\"SS400\",\"SM45C\"]','[\"RB 10\"]',1,'single',7,'RB 10',0.617),
(56,'round-bar','환봉 RB 12',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 12\":{\"SS400\":0.888,\"SM45C\":0.888}}','[\"SS400\",\"SM45C\"]','[\"RB 12\"]',1,'single',7,'RB 12',0.888),
(57,'round-bar','환봉 RB 13',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 13\":{\"SS400\":1.04,\"SM45C\":1.04}}','[\"SS400\",\"SM45C\"]','[\"RB 13\"]',1,'single',7,'RB 13',1.040),
(58,'round-bar','환봉 RB 16',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 16\":{\"SS400\":1.58,\"SM45C\":1.58}}','[\"SS400\",\"SM45C\"]','[\"RB 16\"]',1,'single',7,'RB 16',1.580),
(59,'round-bar','환봉 RB 19',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 19\":{\"SS400\":2.23,\"SM45C\":2.23}}','[\"SS400\",\"SM45C\"]','[\"RB 19\"]',1,'single',7,'RB 19',2.230),
(60,'round-bar','환봉 RB 22',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 22\":{\"SS400\":2.98,\"SM45C\":2.98}}','[\"SS400\",\"SM45C\"]','[\"RB 22\"]',1,'single',7,'RB 22',2.980),
(61,'round-bar','환봉 RB 25',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 25\":{\"SS400\":3.85,\"SM45C\":3.85}}','[\"SS400\",\"SM45C\"]','[\"RB 25\"]',1,'single',7,'RB 25',3.850),
(62,'round-bar','환봉 RB 28',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 28\":{\"SS400\":4.83,\"SM45C\":4.83}}','[\"SS400\",\"SM45C\"]','[\"RB 28\"]',1,'single',7,'RB 28',4.830),
(63,'round-bar','환봉 RB 32',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 32\":{\"SS400\":6.31,\"SM45C\":6.31}}','[\"SS400\",\"SM45C\"]','[\"RB 32\"]',1,'single',7,'RB 32',6.310),
(64,'round-bar','환봉 RB 35',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 35\":{\"SS400\":7.55,\"SM45C\":7.55}}','[\"SS400\",\"SM45C\"]','[\"RB 35\"]',1,'single',7,'RB 35',7.550),
(65,'round-bar','환봉 RB 38',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 38\":{\"SS400\":8.9,\"SM45C\":8.9}}','[\"SS400\",\"SM45C\"]','[\"RB 38\"]',1,'single',7,'RB 38',8.900),
(66,'round-bar','환봉 RB 42',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 42\":{\"SS400\":10.9,\"SM45C\":10.9}}','[\"SS400\",\"SM45C\"]','[\"RB 42\"]',1,'single',7,'RB 42',10.900),
(67,'round-bar','환봉 RB 45',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 45\":{\"SS400\":12.5,\"SM45C\":12.5}}','[\"SS400\",\"SM45C\"]','[\"RB 45\"]',1,'single',7,'RB 45',12.500),
(68,'round-bar','환봉 RB 50',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','linear','{\"RB 50\":{\"SS400\":15.4,\"SM45C\":15.4}}','[\"SS400\",\"SM45C\"]','[\"RB 50\"]',1,'single',7,'RB 50',15.400),
(69,'steel-plate','HR철판 1.6T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"1.6T*3\'*6\'\":{\"SPHC\":22.7,\"SS400\":22.7}}','[\"SPHC\",\"SS400\"]','[\"1.6T*3\'*6\'\"]',1,'single',8,'1.6T*3\'*6\'',22.700),
(70,'steel-plate','HR철판 2.0T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"2.0T*3\'*6\'\":{\"SPHC\":28.4,\"SS400\":28.4}}','[\"SPHC\",\"SS400\"]','[\"2.0T*3\'*6\'\"]',1,'single',8,'2.0T*3\'*6\'',28.400),
(71,'steel-plate','HR철판 2.3T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"2.3T*3\'*6\'\":{\"SPHC\":32.6,\"SS400\":32.6}}','[\"SPHC\",\"SS400\"]','[\"2.3T*3\'*6\'\"]',1,'single',8,'2.3T*3\'*6\'',32.600),
(72,'steel-plate','HR철판 2.6T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"2.6T*3\'*6\'\":{\"SPHC\":36.8,\"SS400\":36.8}}','[\"SPHC\",\"SS400\"]','[\"2.6T*3\'*6\'\"]',1,'single',8,'2.6T*3\'*6\'',36.800),
(73,'steel-plate','HR철판 3.2T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:22:05','2025-08-31 13:55:13','sheet','{\"3.2T*3\'*6\'\":{\"SS400\":45.3}}','[\"SPHC\",\"SS400\"]','[\"3.2T*3\'*6\'\"]',1,'single',8,'3.2T*3\'*6\'',45.300),
(74,'steel-plate','HR철판 3.2T*4\'*8\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"3.2T*4\'*8\'\":{\"SS400\":80.5}}','[\"SPHC\",\"SS400\"]','[\"3.2T*4\'*8\'\"]',1,'single',8,'3.2T*4\'*8\'',80.500),
(75,'steel-plate','HR철판 4.5T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"4.5T*3\'*6\'\":{\"SS400\":63.7}}','[\"SPHC\",\"SS400\"]','[\"4.5T*3\'*6\'\"]',1,'single',8,'4.5T*3\'*6\'',63.700),
(76,'steel-plate','HR철판 4.5T*4\'*8\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"4.5T*4\'*8\'\":{\"SS400\":113.3}}','[\"SPHC\",\"SS400\"]','[\"4.5T*4\'*8\'\"]',1,'single',8,'4.5T*4\'*8\'',113.300),
(77,'steel-plate','HR철판 4.5T*5\'*10\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"4.5T*5\'*10\'\":{\"SS400\":177.1}}','[\"SPHC\",\"SS400\"]','[\"4.5T*5\'*10\'\"]',1,'single',8,'4.5T*5\'*10\'',177.100),
(78,'steel-plate','HR철판 6.0T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"6.0T*3\'*6\'\":{\"SS400\":85}}','[\"SPHC\",\"SS400\"]','[\"6.0T*3\'*6\'\"]',1,'single',8,'6.0T*3\'*6\'',85.000),
(79,'steel-plate','HR철판 6.0T*4\'*8\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"6.0T*4\'*8\'\":{\"SS400\":151.1}}','[\"SPHC\",\"SS400\"]','[\"6.0T*4\'*8\'\"]',1,'single',8,'6.0T*4\'*8\'',151.100),
(80,'steel-plate','HR철판 6.0T*5\'*10\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"6.0T*5\'*10\'\":{\"SS400\":236.1}}','[\"SPHC\",\"SS400\"]','[\"6.0T*5\'*10\'\"]',1,'single',8,'6.0T*5\'*10\'',236.100),
(81,'steel-plate','HR철판 9.0T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"9.0T*3\'*6\'\":{\"SS400\":127.5}}','[\"SPHC\",\"SS400\"]','[\"9.0T*3\'*6\'\"]',1,'single',8,'9.0T*3\'*6\'',127.500),
(82,'steel-plate','HR철판 9.0T*4\'*8\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"9.0T*4\'*8\'\":{\"SS400\":226.6}}','[\"SPHC\",\"SS400\"]','[\"9.0T*4\'*8\'\"]',1,'single',8,'9.0T*4\'*8\'',226.600),
(83,'steel-plate','HR철판 9.0T*5\'*10\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"9.0T*5\'*10\'\":{\"SS400\":354.1}}','[\"SPHC\",\"SS400\"]','[\"9.0T*5\'*10\'\"]',1,'single',8,'9.0T*5\'*10\'',354.100),
(84,'steel-plate','HR철판 12T*3\'*6\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"12T*3\'*6\'\":{\"SS400\":169.9}}','[\"SPHC\",\"SS400\"]','[\"12T*3\'*6\'\"]',1,'single',8,'12T*3\'*6\'',169.900),
(85,'steel-plate','HR철판 12T*4\'*8\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,13,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"12T*4\'*8\'\":{\"SS400\":302.2}}','[\"SPHC\",\"SS400\"]','[\"12T*4\'*8\'\"]',1,'single',8,'12T*4\'*8\'',302.200),
(86,'steel-plate','HR철판 12T*5\'*10\'',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,2,'2025-08-31 06:22:05','2025-08-31 13:36:37','sheet','{\"12T*5\'*10\'\":{\"SS400\":472.2}}','[\"SPHC\",\"SS400\"]','[\"12T*5\'*10\'\"]',1,'single',8,'12T*5\'*10\'',472.200),
(87,'c-beam','C형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"60*30*10*1.6\":{\"SS400\":1.63},\"60*30*10*1.8\":{\"SS400\":1.81},\"60*30*10*2.0\":{\"SS400\":1.99},\"60*30*10*2.1\":{\"SS400\":2.08},\"60*30*10*2.3\":{\"SS400\":2.25},\"75*45*15*1.6\":{\"SS400\":2.32},\"75*45*15*1.8\":{\"SS400\":2.59},\"75*45*15*2.0\":{\"SS400\":2.86},\"75*45*15*2.1\":{\"SS400\":2.99},\"75*45*15*2.3\":{\"SS400\":3.25},\"90*45*20*2.1\":{\"SS400\":3.25},\"90*45*20*2.3\":{\"SS400\":3.7},\"90*45*20*3.2\":{\"SS400\":5},\"90*50*20*3.2\":{\"SS400\":5.25},\"100*50*20*1.6\":{\"SS400\":2.88},\"100*50*20*1.8\":{\"SS400\":3.22},\"100*50*20*2.0\":{\"SS400\":3.56},\"100*50*20*2.1\":{\"SS400\":3.73},\"100*50*20*2.3\":{\"SS400\":4.06},\"100*50*20*2.6\":{\"SS400\":4.55},\"100*50*20*3.0\":{\"SS400\":5.19},\"100*50*20*3.2\":{\"SS400\":5.5},\"125*50*20*2.0\":{\"SS400\":3.95},\"125*50*20*2.1\":{\"SS400\":4.14},\"125*50*20*2.3\":{\"SS400\":4.51},\"125*50*20*3.0\":{\"SS400\":6.13},\"125*50*20*3.2\":{\"SS400\":6.13},\"150*50*20*2.1\":{\"SS400\":4.55},\"150*50*20*2.3\":{\"SS400\":4.96},\"150*50*20*3.0\":{\"SS400\":6.37},\"150*50*20*3.2\":{\"SS400\":6.76},\"150*65*20*3.0\":{\"SS400\":7.07},\"150*65*20*3.2\":{\"SS400\":7.51},\"150*65*20*4.0\":{\"SS400\":9.22},\"150*65*20*4.5\":{\"SS400\":10.3},\"150*75*20*3.0\":{\"SS400\":7.78},\"150*75*25*3.2\":{\"SS400\":8.27},\"200*75*20*3.0\":{\"SS400\":7.78},\"200*75*20*3.2\":{\"SS400\":9.27},\"200*75*20*4.5\":{\"SS400\":12.7},\"200*75*20*5.0\":{\"SS400\":14},\"200*75*25*3.2\":{\"SS400\":9.52},\"200*75*25*4.0\":{\"SS400\":11.7},\"200*75*25*4.5\":{\"SS400\":13.1},\"200*80*20*4.0\":{\"SS400\":13.3},\"250*80*20*4.5\":{\"SS400\":14.9}}','[\"SS400\"]','[\"60*30*10*1.6\",\"60*30*10*1.8\",\"60*30*10*2.0\",\"60*30*10*2.1\",\"60*30*10*2.3\",\"75*45*15*1.6\",\"75*45*15*1.8\",\"75*45*15*2.0\",\"75*45*15*2.1\",\"75*45*15*2.3\",\"90*45*20*2.1\",\"90*45*20*2.3\",\"90*45*20*3.2\",\"90*50*20*3.2\",\"100*50*20*1.6\",\"100*50*20*1.8\",\"100*50*20*2.0\",\"100*50*20*2.1\",\"100*50*20*2.3\",\"100*50*20*2.6\",\"100*50*20*3.0\",\"100*50*20*3.2\",\"125*50*20*2.0\",\"125*50*20*2.1\",\"125*50*20*2.3\",\"125*50*20*3.0\",\"125*50*20*3.2\",\"150*50*20*2.1\",\"150*50*20*2.3\",\"150*50*20*3.0\",\"150*50*20*3.2\",\"150*65*20*3.0\",\"150*65*20*3.2\",\"150*65*20*4.0\",\"150*65*20*4.5\",\"150*75*20*3.0\",\"150*75*25*3.2\",\"200*75*20*3.0\",\"200*75*20*3.2\",\"200*75*20*4.5\",\"200*75*20*5.0\",\"200*75*25*3.2\",\"200*75*25*4.0\",\"200*75*25*4.5\",\"200*80*20*4.0\",\"250*80*20*4.5\"]',1,'by_specification',NULL,NULL,NULL),
(88,'c-beam','C형강 75*45*15*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"75*45*15*1.6T\":{\"SS400\":2.13}}','[\"SS400\"]','[\"75*45*15*1.6T\"]',1,'single',87,'75*45*15*1.6T',2.130),
(89,'c-beam','C형강 100*50*20*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"100*50*20*2.3T\":{\"SS400\":3.72}}','[\"SS400\"]','[\"100*50*20*2.3T\"]',1,'single',87,'100*50*20*2.3T',3.720),
(90,'c-beam','C형강 125*60*30*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"125*60*30*2.3T\":{\"SS400\":5.16}}','[\"SS400\"]','[\"125*60*30*2.3T\"]',1,'single',87,'125*60*30*2.3T',5.160),
(91,'c-beam','C형강 150*75*30*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"150*75*30*2.3T\":{\"SS400\":6.45}}','[\"SS400\"]','[\"150*75*30*2.3T\"]',1,'single',87,'150*75*30*2.3T',6.450),
(92,'c-beam','C형강 175*75*30*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"175*75*30*2.3T\":{\"SS400\":7.39}}','[\"SS400\"]','[\"175*75*30*2.3T\"]',1,'single',87,'175*75*30*2.3T',7.390),
(93,'c-beam','C형강 200*80*30*3.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"200*80*30*3.2T\":{\"SS400\":11.3}}','[\"SS400\"]','[\"200*80*30*3.2T\"]',1,'single',87,'200*80*30*3.2T',11.300),
(94,'c-beam','C형강 250*80*30*3.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:23:36','2025-08-31 13:36:37','linear','{\"250*80*30*3.2T\":{\"SS400\":13.6}}','[\"SS400\"]','[\"250*80*30*3.2T\"]',1,'single',87,'250*80*30*3.2T',13.600),
(96,'unequal-angle','부등변ㄱ형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"50*30*3T\":{\"SS400\":1.83},\"90*75*9T\":{\"SS400\":11},\"100*75*7T\":{\"SS400\":9.32},\"100*75*10T\":{\"SS400\":13},\"125*75*7T\":{\"SS400\":10.7},\"125*75*10T\":{\"SS400\":14.9},\"125*75*13T\":{\"SS400\":19.1},\"125*90*10T\":{\"SS400\":16.1},\"125*90*13T\":{\"SS400\":20.6},\"150*90*9T\":{\"SS400\":16.4},\"150*90*12T\":{\"SS400\":21.5},\"150*100*9T\":{\"SS400\":17.1},\"150*100*12T\":{\"SS400\":22.4},\"150*100*15T\":{\"SS400\":27.7}}','[\"SS400\"]','[\"50*30*3T\",\"90*75*9T\",\"100*75*7T\",\"100*75*10T\",\"125*75*7T\",\"125*75*10T\",\"125*75*13T\",\"125*90*10T\",\"125*90*13T\",\"150*90*9T\",\"150*90*12T\",\"150*100*9T\",\"150*100*12T\",\"150*100*15T\"]',1,'by_specification',NULL,NULL,NULL),
(97,'unequal-angle','부등변ㄱ형강 75*50*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"75*50*6T\":{\"SS400\":5.23}}','[\"SS400\"]','[\"75*50*6T\"]',1,'single',96,'75*50*6T',5.230),
(98,'unequal-angle','부등변ㄱ형강 90*75*6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"90*75*6T\":{\"SS400\":6.85}}','[\"SS400\"]','[\"90*75*6T\"]',1,'single',96,'90*75*6T',6.850),
(99,'unequal-angle','부등변ㄱ형강 90*75*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"90*75*9T\":{\"SS400\":10}}','[\"SS400\"]','[\"90*75*9T\"]',1,'single',96,'90*75*9T',10.000),
(100,'unequal-angle','부등변ㄱ형강 100*75*7T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"100*75*7T\":{\"SS400\":8.79}}','[\"SS400\"]','[\"100*75*7T\"]',1,'single',96,'100*75*7T',8.790),
(101,'unequal-angle','부등변ㄱ형강 100*75*10T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"100*75*10T\":{\"SS400\":12.2}}','[\"SS400\"]','[\"100*75*10T\"]',1,'single',96,'100*75*10T',12.200),
(102,'unequal-angle','부등변ㄱ형강 125*75*7T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"125*75*7T\":{\"SS400\":10.2}}','[\"SS400\"]','[\"125*75*7T\"]',1,'single',96,'125*75*7T',10.200),
(103,'unequal-angle','부등변ㄱ형강 125*75*10T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"125*75*10T\":{\"SS400\":14.3}}','[\"SS400\"]','[\"125*75*10T\"]',1,'single',96,'125*75*10T',14.300),
(104,'unequal-angle','부등변ㄱ형강 125*90*10T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"125*90*10T\":{\"SS400\":15.5}}','[\"SS400\"]','[\"125*90*10T\"]',1,'single',96,'125*90*10T',15.500),
(105,'unequal-angle','부등변ㄱ형강 150*90*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"150*90*9T\":{\"SS400\":15}}','[\"SS400\"]','[\"150*90*9T\"]',1,'single',96,'150*90*9T',15.000),
(106,'unequal-angle','부등변ㄱ형강 150*90*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"150*90*12T\":{\"SS400\":19.7}}','[\"SS400\"]','[\"150*90*12T\"]',1,'single',96,'150*90*12T',19.700),
(107,'unequal-angle','부등변ㄱ형강 150*100*10T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"150*100*10T\":{\"SS400\":17.9}}','[\"SS400\"]','[\"150*100*10T\"]',1,'single',96,'150*100*10T',17.900),
(108,'unequal-angle','부등변ㄱ형강 150*100*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"150*100*12T\":{\"SS400\":21.2}}','[\"SS400\"]','[\"150*100*12T\"]',1,'single',96,'150*100*12T',21.200),
(109,'square-pipe','사각파이프',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"15*15*1.0T\":{\"HR\":0.419,\"SS400\":0.419},\"15*15*1.2T\":{\"COLOR\":0.491,\"SS400\":0.491},\"15*15*1.6T\":{\"HGI\":0.621,\"SS400\":0.621},\"19*19*1.0T\":{\"GI\":0.545,\"SS400\":0.545},\"19*19*1.2T\":{\"SS400\":0.642},\"19*19*1.6T\":{\"SS400\":0.822},\"20*20*1.2T\":{\"SS400\":0.697},\"20*20*1.4T\":{\"SS400\":0.872},\"25*25*1.2T\":{\"SS400\":0.867},\"25*25*1.4T\":{\"SS400\":1.12},\"30*30*1.2T\":{\"SS400\":1.06},\"30*30*1.4T\":{\"SS400\":1.38},\"40*40*1.4T\":{\"SS400\":1.88},\"40*40*2.0T\":{\"SS400\":2.62},\"50*50*1.4T\":{\"SS400\":2.38},\"50*50*2.0T\":{\"SS400\":3.34},\"50*50*2.9T\":{\"SS400\":4.5},\"75*75*1.4T\":{\"SS400\":3.64},\"75*75*2.0T\":{\"SS400\":5.14},\"75*75*2.9T\":{\"SS400\":7.01},\"100*100*2.0T\":{\"SS400\":6.95},\"100*100*2.9T\":{\"SS400\":9.52},\"100*100*4.0T\":{\"SS400\":11.7},\"100*100*6.0T\":{\"SS400\":17},\"100*100*9.0T\":{\"SS400\":24.1},\"125*125*2.9T\":{\"SS400\":12},\"125*125*4.0T\":{\"SS400\":16.6},\"125*125*5.0T\":{\"SS400\":18.3},\"125*125*6.0T\":{\"SS400\":21.7},\"125*125*9.0T\":{\"SS400\":31.1},\"150*150*4.0T\":{\"SS400\":20.1},\"150*150*5.0T\":{\"SS400\":22.3},\"150*150*6.0T\":{\"SS400\":26.4},\"150*150*9.0T\":{\"SS400\":38.21},\"200*200*4.5T\":{\"SS400\":27.2},\"200*200*5.0T\":{\"SS400\":35.8},\"200*200*6.0T\":{\"SS400\":46.9},\"200*200*9.0T\":{\"SS400\":52.3},\"250*250*5.0T\":{\"SS400\":38},\"250*250*6.0T\":{\"SS400\":45.2},\"250*250*8.0T\":{\"SS400\":59.5},\"250*250*9.0T\":{\"SS400\":66.5}}','[\"SS400\",\"HR\",\"COLOR\",\"HGI\",\"GI\"]','[\"15*15*1.0T\",\"15*15*1.2T\",\"15*15*1.6T\",\"19*19*1.0T\",\"19*19*1.2T\",\"19*19*1.6T\",\"20*20*1.2T\",\"20*20*1.4T\",\"25*25*1.2T\",\"25*25*1.4T\",\"30*30*1.2T\",\"30*30*1.4T\",\"40*40*1.4T\",\"40*40*2.0T\",\"50*50*1.4T\",\"50*50*2.0T\",\"50*50*2.9T\",\"75*75*1.4T\",\"75*75*2.0T\",\"75*75*2.9T\",\"100*100*2.0T\",\"100*100*2.9T\",\"100*100*4.0T\",\"100*100*6.0T\",\"100*100*9.0T\",\"125*125*2.9T\",\"125*125*4.0T\",\"125*125*5.0T\",\"125*125*6.0T\",\"125*125*9.0T\",\"150*150*4.0T\",\"150*150*5.0T\",\"150*150*6.0T\",\"150*150*9.0T\",\"200*200*4.5T\",\"200*200*5.0T\",\"200*200*6.0T\",\"200*200*9.0T\",\"250*250*5.0T\",\"250*250*6.0T\",\"250*250*8.0T\",\"250*250*9.0T\"]',1,'by_specification',NULL,NULL,NULL),
(110,'square-pipe','사각파이프 12*12*0.7T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"12*12*0.7T\":{\"SS400\":0.243}}','[\"SS400\"]','[\"12*12*0.7T\"]',1,'single',109,'12*12*0.7T',0.243),
(111,'square-pipe','사각파이프 16*16*1.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"16*16*1.0T\":{\"SS400\":0.461}}','[\"SS400\"]','[\"16*16*1.0T\"]',1,'single',109,'16*16*1.0T',0.461),
(112,'square-pipe','사각파이프 19*19*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"19*19*1.2T\":{\"SS400\":0.665}}','[\"SS400\"]','[\"19*19*1.2T\"]',1,'single',109,'19*19*1.2T',0.665),
(113,'square-pipe','사각파이프 25*25*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"25*25*1.2T\":{\"SS400\":0.889}}','[\"SS400\"]','[\"25*25*1.2T\"]',1,'single',109,'25*25*1.2T',0.889),
(114,'square-pipe','사각파이프 25*25*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"25*25*1.6T\":{\"SS400\":1.17}}','[\"SS400\"]','[\"25*25*1.6T\"]',1,'single',109,'25*25*1.6T',1.170),
(115,'square-pipe','사각파이프 30*30*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"30*30*1.6T\":{\"SS400\":1.42}}','[\"SS400\"]','[\"30*30*1.6T\"]',1,'single',109,'30*30*1.6T',1.420),
(116,'square-pipe','사각파이프 40*40*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"40*40*1.6T\":{\"SS400\":1.92}}','[\"SS400\"]','[\"40*40*1.6T\"]',1,'single',109,'40*40*1.6T',1.920),
(117,'square-pipe','사각파이프 40*40*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"40*40*2.3T\":{\"SS400\":2.69}}','[\"SS400\"]','[\"40*40*2.3T\"]',1,'single',109,'40*40*2.3T',2.690),
(118,'square-pipe','사각파이프 50*50*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"50*50*1.6T\":{\"SS400\":2.42}}','[\"SS400\"]','[\"50*50*1.6T\"]',1,'single',109,'50*50*1.6T',2.420),
(119,'square-pipe','사각파이프 50*50*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"50*50*2.3T\":{\"SS400\":3.41}}','[\"SS400\"]','[\"50*50*2.3T\"]',1,'single',109,'50*50*2.3T',3.410),
(120,'square-pipe','사각파이프 50*50*3.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"50*50*3.2T\":{\"SS400\":4.58}}','[\"SS400\"]','[\"50*50*3.2T\"]',1,'single',109,'50*50*3.2T',4.580),
(121,'square-pipe','사각파이프 60*60*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"60*60*2.3T\":{\"SS400\":4.13}}','[\"SS400\"]','[\"60*60*2.3T\"]',1,'single',109,'60*60*2.3T',4.130),
(122,'square-pipe','사각파이프 60*60*3.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"60*60*3.2T\":{\"SS400\":5.58}}','[\"SS400\"]','[\"60*60*3.2T\"]',1,'single',109,'60*60*3.2T',5.580),
(123,'square-pipe','사각파이프 75*75*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:45','2025-08-31 13:36:37','linear','{\"75*75*2.3T\":{\"SS400\":5.21}}','[\"SS400\"]','[\"75*75*2.3T\"]',1,'single',109,'75*75*2.3T',5.210),
(124,'square-pipe','사각파이프 75*75*3.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:46','2025-08-31 13:36:37','linear','{\"75*75*3.2T\":{\"SS400\":7.08}}','[\"SS400\"]','[\"75*75*3.2T\"]',1,'single',109,'75*75*3.2T',7.080),
(125,'square-pipe','사각파이프 100*100*3.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:46','2025-08-31 13:36:37','linear','{\"100*100*3.2T\":{\"SS400\":9.58}}','[\"SS400\"]','[\"100*100*3.2T\"]',1,'single',109,'100*100*3.2T',9.580),
(126,'square-pipe','사각파이프 100*100*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,1,'2025-08-31 06:24:46','2025-08-31 13:36:37','linear','{\"100*100*4.5T\":{\"SS400\":13.2}}','[\"SS400\"]','[\"100*100*4.5T\"]',1,'single',109,'100*100*4.5T',13.200),
(127,'square-pipe','사각파이프 125*125*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 06:24:46','2025-08-31 13:36:37','linear','{\"125*125*4.5T\":{\"SS400\":16.7}}','[\"SS400\"]','[\"125*125*4.5T\"]',1,'single',109,'125*125*4.5T',16.700),
(129,'square-pipe','사각파이프 150*150*6.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,1,'2025-08-31 06:24:46','2025-08-31 13:36:37','linear','{\"150*150*6.0T\":{\"SS400\":26.5}}','[\"SS400\"]','[\"150*150*6.0T\"]',1,'single',109,'150*150*6.0T',26.500),
(130,'light-h-beam','경량H형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"100*50*3.2*4.5\":{\"SS400\":7.45},\"125*60*3.2*4.5\":{\"SS400\":8.96},\"150*75*3.2*4.5\":{\"SS400\":11.2},\"175*90*3.2*5\":{\"SS400\":14.4},\"200*100*3.2*5\":{\"SS400\":16.7},\"250*125*3.2*5\":{\"SS400\":21.3},\"250*125*4.5*6\":{\"SS400\":27.3},\"300*150*4.5*6\":{\"SS400\":33},\"300*150*4.5*9\":{\"SS400\":40.8},\"350*175*4.5*7\":{\"SS400\":41.4},\"350*175*4.5*9\":{\"SS400\":47.2},\"400*200*4.5*7\":{\"SS400\":47.9},\"400*200*6*9\":{\"SS400\":63},\"450*200*6*9\":{\"SS400\":69.3},\"500*200*6*9\":{\"SS400\":75.6},\"500*200*7*12\":{\"SS400\":88.7},\"600*200*7*12\":{\"SS400\":101.3},\"600*200*8*14\":{\"SS400\":117}}','[\"SS400\"]','[\"100*50*3.2*4.5\",\"125*60*3.2*4.5\",\"150*75*3.2*4.5\",\"175*90*3.2*5\",\"200*100*3.2*5\",\"250*125*3.2*5\",\"250*125*4.5*6\",\"300*150*4.5*6\",\"300*150*4.5*9\",\"350*175*4.5*7\",\"350*175*4.5*9\",\"400*200*4.5*7\",\"400*200*6*9\",\"450*200*6*9\",\"500*200*6*9\",\"500*200*7*12\",\"600*200*7*12\",\"600*200*8*14\"]',1,'by_specification',NULL,NULL,NULL),
(131,'light-h-beam','경량H형강 100*50*3.2*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"100*50*3.2*4.5\":{\"SS400\":7.45}}','[\"SS400\"]','[\"100*50*3.2*4.5\"]',1,'single',130,'100*50*3.2*4.5',7.450),
(132,'light-h-beam','경량H형강 125*60*3.2*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"125*60*3.2*4.5\":{\"SS400\":8.96}}','[\"SS400\"]','[\"125*60*3.2*4.5\"]',1,'single',130,'125*60*3.2*4.5',8.960),
(133,'light-h-beam','경량H형강 150*75*3.2*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"150*75*3.2*4.5\":{\"SS400\":11.2}}','[\"SS400\"]','[\"150*75*3.2*4.5\"]',1,'single',130,'150*75*3.2*4.5',11.200),
(134,'light-h-beam','경량H형강 175*90*3.2*5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"175*90*3.2*5\":{\"SS400\":14.4}}','[\"SS400\"]','[\"175*90*3.2*5\"]',1,'single',130,'175*90*3.2*5',14.400),
(135,'light-h-beam','경량H형강 200*100*3.2*5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"200*100*3.2*5\":{\"SS400\":16.7}}','[\"SS400\"]','[\"200*100*3.2*5\"]',1,'single',130,'200*100*3.2*5',16.700),
(136,'light-h-beam','경량H형강 250*125*3.2*5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"250*125*3.2*5\":{\"SS400\":21.3}}','[\"SS400\"]','[\"250*125*3.2*5\"]',1,'single',130,'250*125*3.2*5',21.300),
(137,'light-h-beam','경량H형강 250*125*4.5*6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"250*125*4.5*6\":{\"SS400\":27.3}}','[\"SS400\"]','[\"250*125*4.5*6\"]',1,'single',130,'250*125*4.5*6',27.300),
(138,'light-h-beam','경량H형강 300*150*4.5*6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"300*150*4.5*6\":{\"SS400\":33}}','[\"SS400\"]','[\"300*150*4.5*6\"]',1,'single',130,'300*150*4.5*6',33.000),
(139,'light-h-beam','경량H형강 300*150*4.5*9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"300*150*4.5*9\":{\"SS400\":40.8}}','[\"SS400\"]','[\"300*150*4.5*9\"]',1,'single',130,'300*150*4.5*9',40.800),
(140,'light-h-beam','경량H형강 350*175*4.5*7',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"350*175*4.5*7\":{\"SS400\":41.4}}','[\"SS400\"]','[\"350*175*4.5*7\"]',1,'single',130,'350*175*4.5*7',41.400),
(141,'light-h-beam','경량H형강 350*175*4.5*9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"350*175*4.5*9\":{\"SS400\":47.2}}','[\"SS400\"]','[\"350*175*4.5*9\"]',1,'single',130,'350*175*4.5*9',47.200),
(142,'light-h-beam','경량H형강 400*200*4.5*7',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"400*200*4.5*7\":{\"SS400\":47.9}}','[\"SS400\"]','[\"400*200*4.5*7\"]',1,'single',130,'400*200*4.5*7',47.900),
(143,'light-h-beam','경량H형강 400*200*6*9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"400*200*6*9\":{\"SS400\":63}}','[\"SS400\"]','[\"400*200*6*9\"]',1,'single',130,'400*200*6*9',63.000),
(144,'light-h-beam','경량H형강 450*200*6*9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"450*200*6*9\":{\"SS400\":69.3}}','[\"SS400\"]','[\"450*200*6*9\"]',1,'single',130,'450*200*6*9',69.300),
(145,'light-h-beam','경량H형강 500*200*6*9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"500*200*6*9\":{\"SS400\":75.6}}','[\"SS400\"]','[\"500*200*6*9\"]',1,'single',130,'500*200*6*9',75.600),
(146,'light-h-beam','경량H형강 500*200*7*12',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"500*200*7*12\":{\"SS400\":88.7}}','[\"SS400\"]','[\"500*200*7*12\"]',1,'single',130,'500*200*7*12',88.700),
(147,'light-h-beam','경량H형강 600*200*7*12',NULL,'600*200*7*12','경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12경량H형강 600*200*7*12\n\n./114/cnst_banner_800pix.gif',NULL,'',1,'in_stock',NULL,NULL,'','','','','','','[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','',NULL,NULL,0,1,39,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"600*200*7*12\":{\"SS400\":101.3}}','[\"SS400\"]','[\"600*200*7*12\"]',1,'single',130,'600*200*7*12',101.300),
(148,'light-h-beam','경량H형강 600*200*8*14',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:34:23','2025-08-31 13:36:37','linear','{\"600*200*8*14\":{\"SS400\":117}}','[\"SS400\"]','[\"600*200*8*14\"]',1,'single',130,'600*200*8*14',117.000),
(149,'h-beam','H형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"100*100*6*8\":{\"SS400\":17.2,\"SM490A\":17.2,\"SM490B\":17.2},\"125*125*6.5*9\":{\"SS400\":23.8,\"SM490A\":23.8,\"SM490B\":23.8},\"150*150*7*10\":{\"SS400\":31.5,\"SM490A\":31.5,\"SM490B\":31.5},\"175*175*7.5*11\":{\"SS400\":40.2,\"SM490A\":40.2,\"SM490B\":40.2},\"200*200*8*12\":{\"SS400\":49.9,\"SM490A\":49.9,\"SM490B\":49.9},\"250*250*9*14\":{\"SS400\":72.4,\"SM490A\":72.4,\"SM490B\":72.4},\"300*300*10*15\":{\"SS400\":94,\"SM490A\":94,\"SM490B\":94},\"300*300*12*12\":{\"SS400\":94,\"SM490A\":94,\"SM490B\":94},\"350*350*12*19\":{\"SS400\":137,\"SM490A\":137,\"SM490B\":137},\"400*400*13*21\":{\"SS400\":172,\"SM490A\":172,\"SM490B\":172},\"450*400*18*28\":{\"SS400\":233,\"SM490A\":233,\"SM490B\":233},\"500*300*11*18\":{\"SS400\":114,\"SM490A\":114,\"SM490B\":114},\"600*300*12*20\":{\"SS400\":137,\"SM490A\":137,\"SM490B\":137},\"700*300*13*24\":{\"SS400\":173,\"SM490A\":173,\"SM490B\":173},\"800*300*14*26\":{\"SS400\":202,\"SM490A\":202,\"SM490B\":202},\"900*300*16*28\":{\"SS400\":243,\"SM490A\":243,\"SM490B\":243}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"100*100*6*8\",\"125*125*6.5*9\",\"150*150*7*10\",\"175*175*7.5*11\",\"200*200*8*12\",\"250*250*9*14\",\"300*300*10*15\",\"300*300*12*12\",\"350*350*12*19\",\"400*400*13*21\",\"450*400*18*28\",\"500*300*11*18\",\"600*300*12*20\",\"700*300*13*24\",\"800*300*14*26\",\"900*300*16*28\"]',1,'by_specification',NULL,NULL,NULL),
(150,'h-beam','H형강 100*100*6*8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"100*100*6*8\":{\"SS400\":17.2,\"SM490A\":17.2,\"SM490B\":17.2}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"100*100*6*8\"]',1,'single',149,'100*100*6*8',17.200),
(151,'h-beam','H형강 125*125*6.5*9',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"125*125*6.5*9\":{\"SS400\":23.8,\"SM490A\":23.8,\"SM490B\":23.8}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"125*125*6.5*9\"]',1,'single',149,'125*125*6.5*9',23.800),
(152,'h-beam','H형강 150*150*7*10',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"150*150*7*10\":{\"SS400\":31.5,\"SM490A\":31.5,\"SM490B\":31.5}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"150*150*7*10\"]',1,'single',149,'150*150*7*10',31.500),
(153,'h-beam','H형강 175*175*7.5*11',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"175*175*7.5*11\":{\"SS400\":40.2,\"SM490A\":40.2,\"SM490B\":40.2}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"175*175*7.5*11\"]',1,'single',149,'175*175*7.5*11',40.200),
(154,'h-beam','H형강 200*200*8*12',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"200*200*8*12\":{\"SS400\":49.9,\"SM490A\":49.9,\"SM490B\":49.9}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"200*200*8*12\"]',1,'single',149,'200*200*8*12',49.900),
(155,'h-beam','H형강 250*250*9*14',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"250*250*9*14\":{\"SS400\":72.4,\"SM490A\":72.4,\"SM490B\":72.4}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"250*250*9*14\"]',1,'single',149,'250*250*9*14',72.400),
(156,'h-beam','H형강 300*300*10*15',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"300*300*10*15\":{\"SS400\":94,\"SM490A\":94,\"SM490B\":94}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"300*300*10*15\"]',1,'single',149,'300*300*10*15',94.000),
(157,'h-beam','H형강 300*300*12*12',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"300*300*12*12\":{\"SS400\":94,\"SM490A\":94,\"SM490B\":94}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"300*300*12*12\"]',1,'single',149,'300*300*12*12',94.000),
(158,'h-beam','H형강 350*350*12*19',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"350*350*12*19\":{\"SS400\":137,\"SM490A\":137,\"SM490B\":137}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"350*350*12*19\"]',1,'single',149,'350*350*12*19',137.000),
(159,'h-beam','H형강 400*400*13*21',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"400*400*13*21\":{\"SS400\":172,\"SM490A\":172,\"SM490B\":172}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"400*400*13*21\"]',1,'single',149,'400*400*13*21',172.000),
(160,'h-beam','H형강 450*400*18*28',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"450*400*18*28\":{\"SS400\":233,\"SM490A\":233,\"SM490B\":233}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"450*400*18*28\"]',1,'single',149,'450*400*18*28',233.000),
(161,'h-beam','H형강 500*300*11*18',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"500*300*11*18\":{\"SS400\":114,\"SM490A\":114,\"SM490B\":114}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"500*300*11*18\"]',1,'single',149,'500*300*11*18',114.000),
(162,'h-beam','H형강 600*300*12*20',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"600*300*12*20\":{\"SS400\":137,\"SM490A\":137,\"SM490B\":137}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"600*300*12*20\"]',1,'single',149,'600*300*12*20',137.000),
(163,'h-beam','H형강 700*300*13*24',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"700*300*13*24\":{\"SS400\":173,\"SM490A\":173,\"SM490B\":173}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"700*300*13*24\"]',1,'single',149,'700*300*13*24',173.000),
(164,'h-beam','H형강 800*300*14*26',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,4,'2025-08-31 06:35:29','2025-08-31 13:44:05','linear','{\"800*300*14*26\":{\"SS400\":202,\"SM490A\":202,\"SM490B\":202}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"800*300*14*26\"]',1,'single',149,'800*300*14*26',202.000),
(165,'h-beam','H형강 900*300*16*28',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,15,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"900*300*16*28\":{\"SS400\":243,\"SM490A\":243,\"SM490B\":243}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"900*300*16*28\"]',1,'single',149,'900*300*16*28',243.000),
(166,'i-beam','I형강',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"100*75*5*8\":{\"SS400\":13.9},\"125*75*5.5*9.5\":{\"SS400\":16.1},\"150*75*5.5*9.5\":{\"SS400\":17.1},\"150*125*8.5*14\":{\"SS400\":36.2},\"180*100*6*10\":{\"SS400\":23.6},\"200*100*70*10\":{\"SS400\":26},\"200*150*9*16\":{\"SS400\":50.4},\"250*125*7.5*12.5\":{\"SS400\":38.3},\"250*125*10*19\":{\"SS400\":55.5},\"300*150*8*13\":{\"SS400\":48.3},\"300*150*10.5*16.5\":{\"SS400\":62.5},\"350*175*10*16\":{\"SS400\":75},\"400*200*10*16\":{\"SS400\":83.3},\"450*200*11*18\":{\"SS400\":101},\"500*200*11.5*19\":{\"SS400\":113},\"600*220*12*20\":{\"SS400\":133},\"700*250*13*24\":{\"SS400\":183},\"800*280*14*26\":{\"SS400\":219},\"900*300*16*28\":{\"SS400\":258}}','[\"SS400\"]','[\"100*75*5*8\",\"125*75*5.5*9.5\",\"150*75*5.5*9.5\",\"150*125*8.5*14\",\"180*100*6*10\",\"200*100*70*10\",\"200*150*9*16\",\"250*125*7.5*12.5\",\"250*125*10*19\",\"300*150*8*13\",\"300*150*10.5*16.5\",\"350*175*10*16\",\"400*200*10*16\",\"450*200*11*18\",\"500*200*11.5*19\",\"600*220*12*20\",\"700*250*13*24\",\"800*280*14*26\",\"900*300*16*28\"]',1,'by_specification',NULL,NULL,NULL),
(167,'i-beam','I형강 100*75*5*7',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"100*75*5*7\":{\"SS400\":10.1,\"SM490A\":10.1,\"SM490B\":10.1}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"100*75*5*7\"]',1,'single',166,'100*75*5*7',10.100),
(168,'i-beam','I형강 125*75*5.5*7',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"125*75*5.5*7\":{\"SS400\":11.9,\"SM490A\":11.9,\"SM490B\":11.9}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"125*75*5.5*7\"]',1,'single',166,'125*75*5.5*7',11.900),
(169,'i-beam','I형강 150*100*5.5*7',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"150*100*5.5*7\":{\"SS400\":15.5,\"SM490A\":15.5,\"SM490B\":15.5}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"150*100*5.5*7\"]',1,'single',166,'150*100*5.5*7',15.500),
(170,'i-beam','I형강 180*100*6*8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"180*100*6*8\":{\"SS400\":18.9,\"SM490A\":18.9,\"SM490B\":18.9}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"180*100*6*8\"]',1,'single',166,'180*100*6*8',18.900),
(171,'i-beam','I형강 200*100*6.5*8.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"200*100*6.5*8.5\":{\"SS400\":21.7,\"SM490A\":21.7,\"SM490B\":21.7}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"200*100*6.5*8.5\"]',1,'single',166,'200*100*6.5*8.5',21.700),
(172,'i-beam','I형강 220*110*7*9.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"220*110*7*9.2\":{\"SS400\":26.7,\"SM490A\":26.7,\"SM490B\":26.7}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"220*110*7*9.2\"]',1,'single',166,'220*110*7*9.2',26.700),
(173,'i-beam','I형강 250*125*7.5*10',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"250*125*7.5*10\":{\"SS400\":33.4,\"SM490A\":33.4,\"SM490B\":33.4}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"250*125*7.5*10\"]',1,'single',166,'250*125*7.5*10',33.400),
(174,'i-beam','I형강 300*150*8*11',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"300*150*8*11\":{\"SS400\":43.1,\"SM490A\":43.1,\"SM490B\":43.1}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"300*150*8*11\"]',1,'single',166,'300*150*8*11',43.100),
(175,'i-beam','I형강 350*150*9*12',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"350*150*9*12\":{\"SS400\":52.1,\"SM490A\":52.1,\"SM490B\":52.1}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"350*150*9*12\"]',1,'single',166,'350*150*9*12',52.100),
(176,'i-beam','I형강 400*150*10*13',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"400*150*10*13\":{\"SS400\":61.7,\"SM490A\":61.7,\"SM490B\":61.7}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"400*150*10*13\"]',1,'single',166,'400*150*10*13',61.700),
(177,'i-beam','I형강 450*175*11*14',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"450*175*11*14\":{\"SS400\":77.6,\"SM490A\":77.6,\"SM490B\":77.6}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"450*175*11*14\"]',1,'single',166,'450*175*11*14',77.600),
(178,'i-beam','I형강 500*200*12*16',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,2,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"500*200*12*16\":{\"SS400\":99.5,\"SM490A\":99.5,\"SM490B\":99.5}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"500*200*12*16\"]',1,'single',166,'500*200*12*16',99.500),
(179,'i-beam','I형강 550*200*13*17',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,2,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"550*200*13*17\":{\"SS400\":112,\"SM490A\":112,\"SM490B\":112}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"550*200*13*17\"]',1,'single',166,'550*200*13*17',112.000),
(180,'i-beam','I형강 600*200*14*18',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,6,'2025-08-31 06:35:29','2025-08-31 13:36:37','linear','{\"600*200*14*18\":{\"SS400\":125,\"SM490A\":125,\"SM490B\":125}}','[\"SS400\",\"SM490A\",\"SM490B\"]','[\"600*200*14*18\"]',1,'single',166,'600*200*14*18',125.000),
(181,'deck-plate','데크플레이트',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"614*50*1.2T\":{\"SS400\":8.24,\"GI\":8.58},\"614*50*1.6T\":{\"SS400\":10.99,\"GI\":11.32},\"660*50*1.2T\":{\"SS400\":8.61,\"GI\":8.96},\"660*50*1.6T\":{\"SS400\":11.48,\"GI\":11.83},\"600*75*1.2T\":{\"SS400\":9.38,\"GI\":9.76},\"600*75*1.6T\":{\"SS400\":12.5,\"GI\":12.9},\"600*100*1.2T\":{\"SS400\":10.83,\"GI\":11.21},\"600*100*1.6T\":{\"SS400\":14.44}}','[\"SS400\",\"GI\"]','[\"614*50*1.2T\",\"614*50*1.6T\",\"660*50*1.2T\",\"660*50*1.6T\",\"600*75*1.2T\",\"600*75*1.6T\",\"600*100*1.2T\",\"600*100*1.6T\"]',1,'by_specification',NULL,NULL,NULL),
(182,'deck-plate','데크플레이트 0.5T*600*2400',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.5T*600*2400\":{\"SS400\":14.1}}','[\"SS400\"]','[\"0.5T*600*2400\"]',1,'single',181,'0.5T*600*2400',14.100),
(183,'deck-plate','데크플레이트 0.5T*600*3000',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.5T*600*3000\":{\"SS400\":17.7}}','[\"SS400\"]','[\"0.5T*600*3000\"]',1,'single',181,'0.5T*600*3000',17.700),
(184,'deck-plate','데크플레이트 0.5T*600*3600',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.5T*600*3600\":{\"SS400\":21.2}}','[\"SS400\"]','[\"0.5T*600*3600\"]',1,'single',181,'0.5T*600*3600',21.200),
(185,'deck-plate','데크플레이트 0.6T*600*2400',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.6T*600*2400\":{\"SS400\":17}}','[\"SS400\"]','[\"0.6T*600*2400\"]',1,'single',181,'0.6T*600*2400',17.000),
(186,'deck-plate','데크플레이트 0.6T*600*3000',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.6T*600*3000\":{\"SS400\":21.2}}','[\"SS400\"]','[\"0.6T*600*3000\"]',1,'single',181,'0.6T*600*3000',21.200),
(187,'deck-plate','데크플레이트 0.6T*600*3600',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.6T*600*3600\":{\"SS400\":25.4}}','[\"SS400\"]','[\"0.6T*600*3600\"]',1,'single',181,'0.6T*600*3600',25.400),
(188,'deck-plate','데크플레이트 0.8T*600*2400',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.8T*600*2400\":{\"SS400\":22.6}}','[\"SS400\"]','[\"0.8T*600*2400\"]',1,'single',181,'0.8T*600*2400',22.600),
(189,'deck-plate','데크플레이트 0.8T*600*3000',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.8T*600*3000\":{\"SS400\":28.3}}','[\"SS400\"]','[\"0.8T*600*3000\"]',1,'single',181,'0.8T*600*3000',28.300),
(190,'deck-plate','데크플레이트 0.8T*600*3600',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"0.8T*600*3600\":{\"SS400\":33.9}}','[\"SS400\"]','[\"0.8T*600*3600\"]',1,'single',181,'0.8T*600*3600',33.900),
(191,'deck-plate','데크플레이트 1.0T*600*2400',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1.0T*600*2400\":{\"SS400\":28.3}}','[\"SS400\"]','[\"1.0T*600*2400\"]',1,'single',181,'1.0T*600*2400',28.300),
(192,'deck-plate','데크플레이트 1.0T*600*3000',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1.0T*600*3000\":{\"SS400\":35.3}}','[\"SS400\"]','[\"1.0T*600*3000\"]',1,'single',181,'1.0T*600*3000',35.300),
(193,'deck-plate','데크플레이트 1.0T*600*3600',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1.0T*600*3600\":{\"SS400\":42.4}}','[\"SS400\"]','[\"1.0T*600*3600\"]',1,'single',181,'1.0T*600*3600',42.400),
(194,'deck-plate','데크플레이트 1.2T*600*2400',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1.2T*600*2400\":{\"SS400\":33.9}}','[\"SS400\"]','[\"1.2T*600*2400\"]',1,'single',181,'1.2T*600*2400',33.900),
(195,'deck-plate','데크플레이트 1.2T*600*3000',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1.2T*600*3000\":{\"SS400\":42.4}}','[\"SS400\"]','[\"1.2T*600*3000\"]',1,'single',181,'1.2T*600*3000',42.400),
(196,'deck-plate','데크플레이트 1.2T*600*3600',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1.2T*600*3600\":{\"SS400\":50.9}}','[\"SS400\"]','[\"1.2T*600*3600\"]',1,'single',181,'1.2T*600*3600',50.900),
(197,'temporary-deck','복공판',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"1,990X750X200\":{\"SS400\":280}}','[\"SS400\"]','[\"1,990X750X200\"]',1,'by_specification',NULL,NULL,NULL),
(198,'temporary-deck','복공판 22T*914*1829',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"22T*914*1829\":{\"SS400\":290}}','[\"SS400\"]','[\"22T*914*1829\"]',1,'single',197,'22T*914*1829',290.000),
(199,'temporary-deck','복공판 22T*1219*2438',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"22T*1219*2438\":{\"SS400\":515}}','[\"SS400\"]','[\"22T*1219*2438\"]',1,'single',197,'22T*1219*2438',515.000),
(200,'temporary-deck','복공판 22T*1524*3048',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"22T*1524*3048\":{\"SS400\":805}}','[\"SS400\"]','[\"22T*1524*3048\"]',1,'single',197,'22T*1524*3048',805.000),
(201,'temporary-deck','복공판 25T*914*1829',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"25T*914*1829\":{\"SS400\":330}}','[\"SS400\"]','[\"25T*914*1829\"]',1,'single',197,'25T*914*1829',330.000),
(202,'temporary-deck','복공판 25T*1219*2438',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"25T*1219*2438\":{\"SS400\":585}}','[\"SS400\"]','[\"25T*1219*2438\"]',1,'single',197,'25T*1219*2438',585.000),
(203,'temporary-deck','복공판 25T*1524*3048',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"25T*1524*3048\":{\"SS400\":915}}','[\"SS400\"]','[\"25T*1524*3048\"]',1,'single',197,'25T*1524*3048',915.000),
(204,'temporary-deck','복공판 32T*914*1829',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"32T*914*1829\":{\"SS400\":422}}','[\"SS400\"]','[\"32T*914*1829\"]',1,'single',197,'32T*914*1829',422.000),
(205,'temporary-deck','복공판 32T*1219*2438',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"32T*1219*2438\":{\"SS400\":749}}','[\"SS400\"]','[\"32T*1219*2438\"]',1,'single',197,'32T*1219*2438',749.000),
(206,'temporary-deck','복공판 32T*1524*3048',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"32T*1524*3048\":{\"SS400\":1171}}','[\"SS400\"]','[\"32T*1524*3048\"]',1,'single',197,'32T*1524*3048',1171.000),
(207,'temporary-deck','복공판 38T*914*1829',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"38T*914*1829\":{\"SS400\":501}}','[\"SS400\"]','[\"38T*914*1829\"]',1,'single',197,'38T*914*1829',501.000),
(208,'temporary-deck','복공판 38T*1219*2438',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"38T*1219*2438\":{\"SS400\":889}}','[\"SS400\"]','[\"38T*1219*2438\"]',1,'single',197,'38T*1219*2438',889.000),
(209,'temporary-deck','복공판 38T*1524*3048',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','sheet','{\"38T*1524*3048\":{\"SS400\":1389}}','[\"SS400\"]','[\"38T*1524*3048\"]',1,'single',197,'38T*1524*3048',1389.000),
(210,'rail','레일',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"9kg\":{\"SS400\":8.94},\"15kg\":{\"SS400\":15.2},\"22kg\":{\"SS400\":22.3},\"30kg\":{\"SS400\":30.1},\"37kg\":{\"SS400\":37.2},\"50kg\":{\"SS400\":50.4},\"50kg\\/N\":{\"SS400\":50.4},\"60kg\":{\"SS400\":60.8},\"70kg\":{\"SS400\":69.5},\"73kg\":{\"SS400\":73.3}}','[\"SS400\"]','[\"9kg\",\"15kg\",\"22kg\",\"30kg\",\"37kg\",\"50kg\",\"50kg\\/N\",\"60kg\",\"70kg\",\"73kg\"]',1,'by_specification',NULL,NULL,NULL),
(211,'rail','레일 12kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"12kg\\/m\":{\"SS400\":12}}','[\"SS400\"]','[\"12kg\\/m\"]',1,'single',210,'12kg/m',12.000),
(212,'rail','레일 15kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"15kg\\/m\":{\"SS400\":15}}','[\"SS400\"]','[\"15kg\\/m\"]',1,'single',210,'15kg/m',15.000),
(213,'rail','레일 22kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"22kg\\/m\":{\"SS400\":22.4}}','[\"SS400\"]','[\"22kg\\/m\"]',1,'single',210,'22kg/m',22.400),
(214,'rail','레일 30kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"30kg\\/m\":{\"SS400\":30.1}}','[\"SS400\"]','[\"30kg\\/m\"]',1,'single',210,'30kg/m',30.100),
(215,'rail','레일 37kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"37kg\\/m\":{\"SS400\":37.1}}','[\"SS400\"]','[\"37kg\\/m\"]',1,'single',210,'37kg/m',37.100),
(216,'rail','레일 40kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"40kg\\/m\":{\"SS400\":40.6}}','[\"SS400\"]','[\"40kg\\/m\"]',1,'single',210,'40kg/m',40.600),
(217,'rail','레일 50kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"50kg\\/m\":{\"SS400\":50.4}}','[\"SS400\"]','[\"50kg\\/m\"]',1,'single',210,'50kg/m',50.400),
(218,'rail','레일 60kg/m',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 06:36:36','2025-08-31 13:36:37','linear','{\"60kg\\/m\":{\"SS400\":60.8}}','[\"SS400\"]','[\"60kg\\/m\"]',1,'single',210,'60kg/m',60.800),
(219,'rebar','철근 D10',NULL,'직경: 9.53mm, 단위중량: 0.56kg/m','소형 구조물, 슬래브 배근용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,2,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(220,'rebar','철근 D13',NULL,'직경: 12.7mm, 단위중량: 0.995kg/m','일반 구조물, 기초 배근용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(221,'rebar','철근 D16',NULL,'직경: 15.9mm, 단위중량: 1.56kg/m','중형 구조물, 보·기둥 배근용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(222,'rebar','철근 D19',NULL,'직경: 19.1mm, 단위중량: 2.25kg/m','중형 구조물, 보·기둥 주근용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(223,'rebar','철근 D22',NULL,'직경: 22.2mm, 단위중량: 3.04kg/m','대형 구조물, 보·기둥 주근용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(224,'rebar','철근 D25',NULL,'직경: 25.4mm, 단위중량: 3.98kg/m','대형 구조물, 교량·댐 등 특수구조물용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(225,'rebar','철근 D29',NULL,'직경: 28.6mm, 단위중량: 5.04kg/m','특수 구조물, 교량 주형보용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(226,'rebar','철근 D32',NULL,'직경: 31.8mm, 단위중량: 6.23kg/m','특수 구조물, 대형 교량·댐용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(227,'rebar','철근 D35',NULL,'직경: 34.9mm, 단위중량: 7.51kg/m','초대형 구조물, 특수 토목공사용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(228,'rebar','철근 D38',NULL,'직경: 38.1mm, 단위중량: 8.95kg/m','초대형 구조물, 특수 토목공사용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(229,'rebar','철근 D41',NULL,'직경: 41.3mm, 단위중량: 10.5kg/m','초대형 특수 구조물용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(230,'rebar','철근 D51',NULL,'직경: 50.8mm, 단위중량: 15.9kg/m','초대형 특수 구조물용 철근\n\n./114/cnst_banner_800pix.gif',NULL,'톤',1,'on_order',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 08:41:57','2025-08-31 13:36:37','linear',NULL,NULL,NULL,0,'single',NULL,NULL,NULL),
(231,'c-beam','C형강 60*30*10*1.6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"60*30*10*1.6\":{\"SS400\":1.63}}','[\"SS400\"]','[\"60*30*10*1.6\"]',1,'single',87,'60*30*10*1.6',1.630),
(232,'c-beam','C형강 60*30*10*1.8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"60*30*10*1.8\":{\"SS400\":1.81}}','[\"SS400\"]','[\"60*30*10*1.8\"]',1,'single',87,'60*30*10*1.8',1.810),
(233,'c-beam','C형강 60*30*10*2.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"60*30*10*2.0\":{\"SS400\":1.99}}','[\"SS400\"]','[\"60*30*10*2.0\"]',1,'single',87,'60*30*10*2.0',1.990),
(234,'c-beam','C형강 60*30*10*2.1',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"60*30*10*2.1\":{\"SS400\":2.08}}','[\"SS400\"]','[\"60*30*10*2.1\"]',1,'single',87,'60*30*10*2.1',2.080),
(235,'c-beam','C형강 60*30*10*2.3',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"60*30*10*2.3\":{\"SS400\":2.25}}','[\"SS400\"]','[\"60*30*10*2.3\"]',1,'single',87,'60*30*10*2.3',2.250),
(236,'c-beam','C형강 75*45*15*1.6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"75*45*15*1.6\":{\"SS400\":2.32}}','[\"SS400\"]','[\"75*45*15*1.6\"]',1,'single',87,'75*45*15*1.6',2.320),
(237,'c-beam','C형강 75*45*15*1.8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"75*45*15*1.8\":{\"SS400\":2.59}}','[\"SS400\"]','[\"75*45*15*1.8\"]',1,'single',87,'75*45*15*1.8',2.590),
(238,'c-beam','C형강 75*45*15*2.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"75*45*15*2.0\":{\"SS400\":2.86}}','[\"SS400\"]','[\"75*45*15*2.0\"]',1,'single',87,'75*45*15*2.0',2.860),
(239,'c-beam','C형강 75*45*15*2.1',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"75*45*15*2.1\":{\"SS400\":2.99}}','[\"SS400\"]','[\"75*45*15*2.1\"]',1,'single',87,'75*45*15*2.1',2.990),
(240,'c-beam','C형강 75*45*15*2.3',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"75*45*15*2.3\":{\"SS400\":3.25}}','[\"SS400\"]','[\"75*45*15*2.3\"]',1,'single',87,'75*45*15*2.3',3.250),
(241,'c-beam','C형강 90*45*20*2.1',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"90*45*20*2.1\":{\"SS400\":3.25}}','[\"SS400\"]','[\"90*45*20*2.1\"]',1,'single',87,'90*45*20*2.1',3.250),
(242,'c-beam','C형강 90*45*20*2.3',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"90*45*20*2.3\":{\"SS400\":3.7}}','[\"SS400\"]','[\"90*45*20*2.3\"]',1,'single',87,'90*45*20*2.3',3.700),
(243,'c-beam','C형강 90*45*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"90*45*20*3.2\":{\"SS400\":5}}','[\"SS400\"]','[\"90*45*20*3.2\"]',1,'single',87,'90*45*20*3.2',5.000),
(244,'c-beam','C형강 90*50*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"90*50*20*3.2\":{\"SS400\":5.25}}','[\"SS400\"]','[\"90*50*20*3.2\"]',1,'single',87,'90*50*20*3.2',5.250),
(245,'c-beam','C형강 100*50*20*1.6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*1.6\":{\"SS400\":2.88}}','[\"SS400\"]','[\"100*50*20*1.6\"]',1,'single',87,'100*50*20*1.6',2.880),
(246,'c-beam','C형강 100*50*20*1.8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*1.8\":{\"SS400\":3.22}}','[\"SS400\"]','[\"100*50*20*1.8\"]',1,'single',87,'100*50*20*1.8',3.220),
(247,'c-beam','C형강 100*50*20*2.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*2.0\":{\"SS400\":3.56}}','[\"SS400\"]','[\"100*50*20*2.0\"]',1,'single',87,'100*50*20*2.0',3.560),
(248,'c-beam','C형강 100*50*20*2.1',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*2.1\":{\"SS400\":3.73}}','[\"SS400\"]','[\"100*50*20*2.1\"]',1,'single',87,'100*50*20*2.1',3.730),
(249,'c-beam','C형강 100*50*20*2.3',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*2.3\":{\"SS400\":4.06}}','[\"SS400\"]','[\"100*50*20*2.3\"]',1,'single',87,'100*50*20*2.3',4.060),
(250,'c-beam','C형강 100*50*20*2.6',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*2.6\":{\"SS400\":4.55}}','[\"SS400\"]','[\"100*50*20*2.6\"]',1,'single',87,'100*50*20*2.6',4.550),
(251,'c-beam','C형강 100*50*20*3.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*3.0\":{\"SS400\":5.19}}','[\"SS400\"]','[\"100*50*20*3.0\"]',1,'single',87,'100*50*20*3.0',5.190),
(252,'c-beam','C형강 100*50*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"100*50*20*3.2\":{\"SS400\":5.5}}','[\"SS400\"]','[\"100*50*20*3.2\"]',1,'single',87,'100*50*20*3.2',5.500),
(253,'c-beam','C형강 125*50*20*2.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"125*50*20*2.0\":{\"SS400\":3.95}}','[\"SS400\"]','[\"125*50*20*2.0\"]',1,'single',87,'125*50*20*2.0',3.950),
(254,'c-beam','C형강 125*50*20*2.1',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"125*50*20*2.1\":{\"SS400\":4.14}}','[\"SS400\"]','[\"125*50*20*2.1\"]',1,'single',87,'125*50*20*2.1',4.140),
(255,'c-beam','C형강 125*50*20*2.3',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"125*50*20*2.3\":{\"SS400\":4.51}}','[\"SS400\"]','[\"125*50*20*2.3\"]',1,'single',87,'125*50*20*2.3',4.510),
(256,'c-beam','C형강 125*50*20*3.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"125*50*20*3.0\":{\"SS400\":6.13}}','[\"SS400\"]','[\"125*50*20*3.0\"]',1,'single',87,'125*50*20*3.0',6.130),
(257,'c-beam','C형강 125*50*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"125*50*20*3.2\":{\"SS400\":6.13}}','[\"SS400\"]','[\"125*50*20*3.2\"]',1,'single',87,'125*50*20*3.2',6.130),
(258,'c-beam','C형강 150*50*20*2.1',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*50*20*2.1\":{\"SS400\":4.55}}','[\"SS400\"]','[\"150*50*20*2.1\"]',1,'single',87,'150*50*20*2.1',4.550),
(259,'c-beam','C형강 150*50*20*2.3',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*50*20*2.3\":{\"SS400\":4.96}}','[\"SS400\"]','[\"150*50*20*2.3\"]',1,'single',87,'150*50*20*2.3',4.960),
(260,'c-beam','C형강 150*50*20*3.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*50*20*3.0\":{\"SS400\":6.37}}','[\"SS400\"]','[\"150*50*20*3.0\"]',1,'single',87,'150*50*20*3.0',6.370),
(261,'c-beam','C형강 150*50*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*50*20*3.2\":{\"SS400\":6.76}}','[\"SS400\"]','[\"150*50*20*3.2\"]',1,'single',87,'150*50*20*3.2',6.760),
(262,'c-beam','C형강 150*65*20*3.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*65*20*3.0\":{\"SS400\":7.07}}','[\"SS400\"]','[\"150*65*20*3.0\"]',1,'single',87,'150*65*20*3.0',7.070),
(263,'c-beam','C형강 150*65*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*65*20*3.2\":{\"SS400\":7.51}}','[\"SS400\"]','[\"150*65*20*3.2\"]',1,'single',87,'150*65*20*3.2',7.510),
(264,'c-beam','C형강 150*65*20*4.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*65*20*4.0\":{\"SS400\":9.22}}','[\"SS400\"]','[\"150*65*20*4.0\"]',1,'single',87,'150*65*20*4.0',9.220),
(265,'c-beam','C형강 150*65*20*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:17','2025-08-31 13:36:37','linear','{\"150*65*20*4.5\":{\"SS400\":10.3}}','[\"SS400\"]','[\"150*65*20*4.5\"]',1,'single',87,'150*65*20*4.5',10.300),
(266,'c-beam','C형강 150*75*20*3.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*75*20*3.0\":{\"SS400\":7.78}}','[\"SS400\"]','[\"150*75*20*3.0\"]',1,'single',87,'150*75*20*3.0',7.780),
(267,'c-beam','C형강 150*75*25*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*75*25*3.2\":{\"SS400\":8.27}}','[\"SS400\"]','[\"150*75*25*3.2\"]',1,'single',87,'150*75*25*3.2',8.270),
(268,'c-beam','C형강 200*75*20*3.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*20*3.0\":{\"SS400\":7.78}}','[\"SS400\"]','[\"200*75*20*3.0\"]',1,'single',87,'200*75*20*3.0',7.780),
(269,'c-beam','C형강 200*75*20*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*20*3.2\":{\"SS400\":9.27}}','[\"SS400\"]','[\"200*75*20*3.2\"]',1,'single',87,'200*75*20*3.2',9.270),
(270,'c-beam','C형강 200*75*20*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*20*4.5\":{\"SS400\":12.7}}','[\"SS400\"]','[\"200*75*20*4.5\"]',1,'single',87,'200*75*20*4.5',12.700),
(271,'c-beam','C형강 200*75*20*5.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*20*5.0\":{\"SS400\":14}}','[\"SS400\"]','[\"200*75*20*5.0\"]',1,'single',87,'200*75*20*5.0',14.000),
(272,'c-beam','C형강 200*75*25*3.2',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*25*3.2\":{\"SS400\":9.52}}','[\"SS400\"]','[\"200*75*25*3.2\"]',1,'single',87,'200*75*25*3.2',9.520),
(273,'c-beam','C형강 200*75*25*4.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*25*4.0\":{\"SS400\":11.7}}','[\"SS400\"]','[\"200*75*25*4.0\"]',1,'single',87,'200*75*25*4.0',11.700),
(274,'c-beam','C형강 200*75*25*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*75*25*4.5\":{\"SS400\":13.1}}','[\"SS400\"]','[\"200*75*25*4.5\"]',1,'single',87,'200*75*25*4.5',13.100),
(275,'c-beam','C형강 200*80*20*4.0',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*80*20*4.0\":{\"SS400\":13.3}}','[\"SS400\"]','[\"200*80*20*4.0\"]',1,'single',87,'200*80*20*4.0',13.300),
(276,'c-beam','C형강 250*80*20*4.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"250*80*20*4.5\":{\"SS400\":14.9}}','[\"SS400\"]','[\"250*80*20*4.5\"]',1,'single',87,'250*80*20*4.5',14.900),
(277,'unequal-angle','부등변ㄱ형강 50*30*3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"50*30*3T\":{\"SS400\":1.83}}','[\"SS400\"]','[\"50*30*3T\"]',1,'single',96,'50*30*3T',1.830),
(278,'unequal-angle','부등변ㄱ형강 125*75*13T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*75*13T\":{\"SS400\":19.1}}','[\"SS400\"]','[\"125*75*13T\"]',1,'single',96,'125*75*13T',19.100),
(279,'unequal-angle','부등변ㄱ형강 125*90*13T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*90*13T\":{\"SS400\":20.6}}','[\"SS400\"]','[\"125*90*13T\"]',1,'single',96,'125*90*13T',20.600),
(280,'unequal-angle','부등변ㄱ형강 150*100*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*100*9T\":{\"SS400\":17.1}}','[\"SS400\"]','[\"150*100*9T\"]',1,'single',96,'150*100*9T',17.100),
(281,'unequal-angle','부등변ㄱ형강 150*100*15T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*100*15T\":{\"SS400\":27.7}}','[\"SS400\"]','[\"150*100*15T\"]',1,'single',96,'150*100*15T',27.700),
(282,'square-pipe','사각파이프 15*15*1.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"15*15*1.0T\":{\"SS400\":0.419}}','[\"SS400\"]','[\"15*15*1.0T\"]',1,'single',109,'15*15*1.0T',0.419),
(283,'square-pipe','사각파이프 15*15*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"15*15*1.2T\":{\"SS400\":0.491}}','[\"SS400\"]','[\"15*15*1.2T\"]',1,'single',109,'15*15*1.2T',0.491),
(284,'square-pipe','사각파이프 15*15*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"15*15*1.6T\":{\"SS400\":0.621}}','[\"SS400\"]','[\"15*15*1.6T\"]',1,'single',109,'15*15*1.6T',0.621),
(285,'square-pipe','사각파이프 19*19*1.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"19*19*1.0T\":{\"SS400\":0.545}}','[\"SS400\"]','[\"19*19*1.0T\"]',1,'single',109,'19*19*1.0T',0.545),
(286,'square-pipe','사각파이프 19*19*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"19*19*1.6T\":{\"SS400\":0.822}}','[\"SS400\"]','[\"19*19*1.6T\"]',1,'single',109,'19*19*1.6T',0.822),
(287,'square-pipe','사각파이프 20*20*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"20*20*1.2T\":{\"SS400\":0.697}}','[\"SS400\"]','[\"20*20*1.2T\"]',1,'single',109,'20*20*1.2T',0.697),
(288,'square-pipe','사각파이프 20*20*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"20*20*1.4T\":{\"SS400\":0.872}}','[\"SS400\"]','[\"20*20*1.4T\"]',1,'single',109,'20*20*1.4T',0.872),
(289,'square-pipe','사각파이프 25*25*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"25*25*1.4T\":{\"SS400\":1.12}}','[\"SS400\"]','[\"25*25*1.4T\"]',1,'single',109,'25*25*1.4T',1.120),
(290,'square-pipe','사각파이프 30*30*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"30*30*1.2T\":{\"SS400\":1.06}}','[\"SS400\"]','[\"30*30*1.2T\"]',1,'single',109,'30*30*1.2T',1.060),
(291,'square-pipe','사각파이프 30*30*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"30*30*1.4T\":{\"SS400\":1.38}}','[\"SS400\"]','[\"30*30*1.4T\"]',1,'single',109,'30*30*1.4T',1.380),
(292,'square-pipe','사각파이프 40*40*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"40*40*1.4T\":{\"SS400\":1.88}}','[\"SS400\"]','[\"40*40*1.4T\"]',1,'single',109,'40*40*1.4T',1.880),
(293,'square-pipe','사각파이프 40*40*2.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"40*40*2.0T\":{\"SS400\":2.62}}','[\"SS400\"]','[\"40*40*2.0T\"]',1,'single',109,'40*40*2.0T',2.620),
(294,'square-pipe','사각파이프 50*50*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"50*50*1.4T\":{\"SS400\":2.38}}','[\"SS400\"]','[\"50*50*1.4T\"]',1,'single',109,'50*50*1.4T',2.380),
(295,'square-pipe','사각파이프 50*50*2.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"50*50*2.0T\":{\"SS400\":3.34}}','[\"SS400\"]','[\"50*50*2.0T\"]',1,'single',109,'50*50*2.0T',3.340),
(296,'square-pipe','사각파이프 50*50*2.9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"50*50*2.9T\":{\"SS400\":4.5}}','[\"SS400\"]','[\"50*50*2.9T\"]',1,'single',109,'50*50*2.9T',4.500),
(297,'square-pipe','사각파이프 75*75*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"75*75*1.4T\":{\"SS400\":3.64}}','[\"SS400\"]','[\"75*75*1.4T\"]',1,'single',109,'75*75*1.4T',3.640),
(298,'square-pipe','사각파이프 75*75*2.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"75*75*2.0T\":{\"SS400\":5.14}}','[\"SS400\"]','[\"75*75*2.0T\"]',1,'single',109,'75*75*2.0T',5.140),
(299,'square-pipe','사각파이프 75*75*2.9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"75*75*2.9T\":{\"SS400\":7.01}}','[\"SS400\"]','[\"75*75*2.9T\"]',1,'single',109,'75*75*2.9T',7.010),
(300,'square-pipe','사각파이프 100*100*2.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"100*100*2.0T\":{\"SS400\":6.95}}','[\"SS400\"]','[\"100*100*2.0T\"]',1,'single',109,'100*100*2.0T',6.950),
(301,'square-pipe','사각파이프 100*100*2.9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"100*100*2.9T\":{\"SS400\":9.52}}','[\"SS400\"]','[\"100*100*2.9T\"]',1,'single',109,'100*100*2.9T',9.520),
(302,'square-pipe','사각파이프 100*100*4.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"100*100*4.0T\":{\"SS400\":11.7}}','[\"SS400\"]','[\"100*100*4.0T\"]',1,'single',109,'100*100*4.0T',11.700),
(303,'square-pipe','사각파이프 100*100*6.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"100*100*6.0T\":{\"SS400\":17}}','[\"SS400\"]','[\"100*100*6.0T\"]',1,'single',109,'100*100*6.0T',17.000),
(304,'square-pipe','사각파이프 100*100*9.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"100*100*9.0T\":{\"SS400\":24.1}}','[\"SS400\"]','[\"100*100*9.0T\"]',1,'single',109,'100*100*9.0T',24.100),
(305,'square-pipe','사각파이프 125*125*2.9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*125*2.9T\":{\"SS400\":12}}','[\"SS400\"]','[\"125*125*2.9T\"]',1,'single',109,'125*125*2.9T',12.000),
(306,'square-pipe','사각파이프 125*125*4.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*125*4.0T\":{\"SS400\":16.6}}','[\"SS400\"]','[\"125*125*4.0T\"]',1,'single',109,'125*125*4.0T',16.600),
(307,'square-pipe','사각파이프 125*125*5.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*125*5.0T\":{\"SS400\":18.3}}','[\"SS400\"]','[\"125*125*5.0T\"]',1,'single',109,'125*125*5.0T',18.300),
(308,'square-pipe','사각파이프 125*125*6.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*125*6.0T\":{\"SS400\":21.7}}','[\"SS400\"]','[\"125*125*6.0T\"]',1,'single',109,'125*125*6.0T',21.700),
(309,'square-pipe','사각파이프 125*125*9.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"125*125*9.0T\":{\"SS400\":31.1}}','[\"SS400\"]','[\"125*125*9.0T\"]',1,'single',109,'125*125*9.0T',31.100),
(310,'square-pipe','사각파이프 150*150*4.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,1,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*150*4.0T\":{\"SS400\":20.1}}','[\"SS400\"]','[\"150*150*4.0T\"]',1,'single',109,'150*150*4.0T',20.100),
(311,'square-pipe','사각파이프 150*150*5.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*150*5.0T\":{\"SS400\":22.3}}','[\"SS400\"]','[\"150*150*5.0T\"]',1,'single',109,'150*150*5.0T',22.300),
(312,'square-pipe','사각파이프 150*150*9.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"150*150*9.0T\":{\"SS400\":38.21}}','[\"SS400\"]','[\"150*150*9.0T\"]',1,'single',109,'150*150*9.0T',38.210),
(313,'square-pipe','사각파이프 200*200*4.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*200*4.5T\":{\"SS400\":27.2}}','[\"SS400\"]','[\"200*200*4.5T\"]',1,'single',109,'200*200*4.5T',27.200),
(314,'square-pipe','사각파이프 200*200*5.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*200*5.0T\":{\"SS400\":35.8}}','[\"SS400\"]','[\"200*200*5.0T\"]',1,'single',109,'200*200*5.0T',35.800),
(315,'square-pipe','사각파이프 200*200*6.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*200*6.0T\":{\"SS400\":46.9}}','[\"SS400\"]','[\"200*200*6.0T\"]',1,'single',109,'200*200*6.0T',46.900),
(316,'square-pipe','사각파이프 200*200*9.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"200*200*9.0T\":{\"SS400\":52.3}}','[\"SS400\"]','[\"200*200*9.0T\"]',1,'single',109,'200*200*9.0T',52.300),
(317,'square-pipe','사각파이프 250*250*5.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"250*250*5.0T\":{\"SS400\":38}}','[\"SS400\"]','[\"250*250*5.0T\"]',1,'single',109,'250*250*5.0T',38.000),
(318,'square-pipe','사각파이프 250*250*6.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,6,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"250*250*6.0T\":{\"SS400\":45.2}}','[\"SS400\"]','[\"250*250*6.0T\"]',1,'single',109,'250*250*6.0T',45.200),
(319,'square-pipe','사각파이프 250*250*8.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,6,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"250*250*8.0T\":{\"SS400\":59.5}}','[\"SS400\"]','[\"250*250*8.0T\"]',1,'single',109,'250*250*8.0T',59.500),
(320,'square-pipe','사각파이프 250*250*9.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,'건축 구조물, 철골 공사, 산업 설비',NULL,NULL,'SS400 구조용 강재','국내 주요 제철소',NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','주문 후 2-3일 이내 배송','KS D 3568 규격 인증','고강도, 경량화, 우수한 내구성',0,1,11,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"250*250*9.0T\":{\"SS400\":66.5}}','[\"SS400\"]','[\"250*250*9.0T\"]',1,'single',109,'250*250*9.0T',66.500),
(321,'bs-pipe','BS파이프',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"15A\":{\"SS400\":0.82},\"20A\":{\"SS400\":1.05},\"25A\":{\"SS400\":1.4},\"32A\":{\"SS400\":1.8},\"40A\":{\"SS400\":2.05},\"50A\":{\"SS400\":2.58},\"65A\":{\"SS400\":3.48},\"80A\":{\"SS400\":4.5},\"90A\":{\"SS400\":5.15},\"100A\":{\"SS400\":5.82},\"125A\":{\"SS400\":9.47},\"150A\":{\"SS400\":11.6},\"200A\":{\"SS400\":21.98}}','[\"SS400\"]','[\"15A\",\"20A\",\"25A\",\"32A\",\"40A\",\"50A\",\"65A\",\"80A\",\"90A\",\"100A\",\"125A\",\"150A\",\"200A\"]',1,'by_specification',NULL,NULL,NULL),
(322,'bs-pipe','BS파이프 15A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"15A\":{\"SS400\":0.82}}','[\"SS400\"]','[\"15A\"]',1,'single',321,'15A',0.820),
(323,'bs-pipe','BS파이프 20A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"20A\":{\"SS400\":1.05}}','[\"SS400\"]','[\"20A\"]',1,'single',321,'20A',1.050),
(324,'bs-pipe','BS파이프 25A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:18','2025-08-31 13:36:37','linear','{\"25A\":{\"SS400\":1.4}}','[\"SS400\"]','[\"25A\"]',1,'single',321,'25A',1.400),
(325,'bs-pipe','BS파이프 32A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"32A\":{\"SS400\":1.8}}','[\"SS400\"]','[\"32A\"]',1,'single',321,'32A',1.800),
(326,'bs-pipe','BS파이프 40A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"40A\":{\"SS400\":2.05}}','[\"SS400\"]','[\"40A\"]',1,'single',321,'40A',2.050),
(327,'bs-pipe','BS파이프 50A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"50A\":{\"SS400\":2.58}}','[\"SS400\"]','[\"50A\"]',1,'single',321,'50A',2.580),
(328,'bs-pipe','BS파이프 65A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"65A\":{\"SS400\":3.48}}','[\"SS400\"]','[\"65A\"]',1,'single',321,'65A',3.480),
(329,'bs-pipe','BS파이프 80A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"80A\":{\"SS400\":4.5}}','[\"SS400\"]','[\"80A\"]',1,'single',321,'80A',4.500),
(330,'bs-pipe','BS파이프 90A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"90A\":{\"SS400\":5.15}}','[\"SS400\"]','[\"90A\"]',1,'single',321,'90A',5.150),
(331,'bs-pipe','BS파이프 100A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"100A\":{\"SS400\":5.82}}','[\"SS400\"]','[\"100A\"]',1,'single',321,'100A',5.820),
(332,'bs-pipe','BS파이프 125A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"125A\":{\"SS400\":9.47}}','[\"SS400\"]','[\"125A\"]',1,'single',321,'125A',9.470),
(333,'bs-pipe','BS파이프 150A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"150A\":{\"SS400\":11.6}}','[\"SS400\"]','[\"150A\"]',1,'single',321,'150A',11.600),
(334,'bs-pipe','BS파이프 200A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"200A\":{\"SS400\":21.98}}','[\"SS400\"]','[\"200A\"]',1,'single',321,'200A',21.980),
(335,'ks-pipe','KS파이프',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"15A\":{\"SS400\":1.15},\"20A\":{\"SS400\":1.47},\"25A\":{\"SS400\":2.22},\"32A\":{\"SS400\":2.85},\"40A\":{\"SS400\":3.27},\"50A\":{\"SS400\":4.67},\"65A\":{\"SS400\":5.93},\"80A\":{\"SS400\":7.58},\"90A\":{\"SS400\":9.63},\"100A\":{\"SS400\":10.88},\"125A\":{\"SS400\":17.77},\"150A\":{\"SS400\":21.73},\"200A\":{\"SS400\":41.18},\"250A\":{\"SS400\":63.01},\"300A\":{\"SS400\":89.17}}','[\"SS400\"]','[\"15A\",\"20A\",\"25A\",\"32A\",\"40A\",\"50A\",\"65A\",\"80A\",\"90A\",\"100A\",\"125A\",\"150A\",\"200A\",\"250A\",\"300A\"]',1,'by_specification',NULL,NULL,NULL),
(336,'ks-pipe','KS파이프 15A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"15A\":{\"SS400\":1.15}}','[\"SS400\"]','[\"15A\"]',1,'single',335,'15A',1.150),
(337,'ks-pipe','KS파이프 20A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"20A\":{\"SS400\":1.47}}','[\"SS400\"]','[\"20A\"]',1,'single',335,'20A',1.470),
(338,'ks-pipe','KS파이프 25A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"25A\":{\"SS400\":2.22}}','[\"SS400\"]','[\"25A\"]',1,'single',335,'25A',2.220),
(339,'ks-pipe','KS파이프 32A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"32A\":{\"SS400\":2.85}}','[\"SS400\"]','[\"32A\"]',1,'single',335,'32A',2.850),
(340,'ks-pipe','KS파이프 40A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"40A\":{\"SS400\":3.27}}','[\"SS400\"]','[\"40A\"]',1,'single',335,'40A',3.270),
(341,'ks-pipe','KS파이프 50A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"50A\":{\"SS400\":4.67}}','[\"SS400\"]','[\"50A\"]',1,'single',335,'50A',4.670),
(342,'ks-pipe','KS파이프 65A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"65A\":{\"SS400\":5.93}}','[\"SS400\"]','[\"65A\"]',1,'single',335,'65A',5.930),
(343,'ks-pipe','KS파이프 80A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"80A\":{\"SS400\":7.58}}','[\"SS400\"]','[\"80A\"]',1,'single',335,'80A',7.580),
(344,'ks-pipe','KS파이프 90A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"90A\":{\"SS400\":9.63}}','[\"SS400\"]','[\"90A\"]',1,'single',335,'90A',9.630),
(345,'ks-pipe','KS파이프 100A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"100A\":{\"SS400\":10.88}}','[\"SS400\"]','[\"100A\"]',1,'single',335,'100A',10.880),
(346,'ks-pipe','KS파이프 125A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"125A\":{\"SS400\":17.77}}','[\"SS400\"]','[\"125A\"]',1,'single',335,'125A',17.770),
(347,'ks-pipe','KS파이프 150A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"150A\":{\"SS400\":21.73}}','[\"SS400\"]','[\"150A\"]',1,'single',335,'150A',21.730),
(348,'ks-pipe','KS파이프 200A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"200A\":{\"SS400\":41.18}}','[\"SS400\"]','[\"200A\"]',1,'single',335,'200A',41.180),
(349,'ks-pipe','KS파이프 250A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"250A\":{\"SS400\":63.01}}','[\"SS400\"]','[\"250A\"]',1,'single',335,'250A',63.010),
(350,'ks-pipe','KS파이프 300A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"300A\":{\"SS400\":89.17}}','[\"SS400\"]','[\"300A\"]',1,'single',335,'300A',89.170),
(351,'structural-pipe','구조관',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"15.9*1.4T\":{\"SS400\":0.501},\"19.1*1.4T\":{\"SS400\":0.611},\"22.2*1.4T\":{\"SS400\":0.718},\"25.4*1.4T\":{\"SS400\":0.829},\"31.8*1.4T\":{\"SS400\":1.05},\"38.1*1.4T\":{\"SS400\":1.267},\"50.8*1.4T\":{\"SS400\":1.705},\"63.5*1.4T\":{\"SS400\":2.144},\"76.2*1.4T\":{\"SS400\":2.582},\"101.6*1.4T\":{\"SS400\":3.946},\"139.7*2.8T\":{\"SS400\":10.842},\"165.1*2.8T\":{\"SS400\":12.845},\"190.5*2.8T\":{\"SS400\":14.848},\"216.0*2.8T\":{\"SS400\":16.851},\"267.0*2.8T\":{\"SS400\":20.858}}','[\"SS400\"]','[\"15.9*1.4T\",\"19.1*1.4T\",\"22.2*1.4T\",\"25.4*1.4T\",\"31.8*1.4T\",\"38.1*1.4T\",\"50.8*1.4T\",\"63.5*1.4T\",\"76.2*1.4T\",\"101.6*1.4T\",\"139.7*2.8T\",\"165.1*2.8T\",\"190.5*2.8T\",\"216.0*2.8T\",\"267.0*2.8T\"]',1,'by_specification',NULL,NULL,NULL),
(352,'structural-pipe','구조관 15.9*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"15.9*1.4T\":{\"SS400\":0.501}}','[\"SS400\"]','[\"15.9*1.4T\"]',1,'single',351,'15.9*1.4T',0.501),
(353,'structural-pipe','구조관 19.1*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"19.1*1.4T\":{\"SS400\":0.611}}','[\"SS400\"]','[\"19.1*1.4T\"]',1,'single',351,'19.1*1.4T',0.611),
(354,'structural-pipe','구조관 22.2*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"22.2*1.4T\":{\"SS400\":0.718}}','[\"SS400\"]','[\"22.2*1.4T\"]',1,'single',351,'22.2*1.4T',0.718),
(355,'structural-pipe','구조관 25.4*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"25.4*1.4T\":{\"SS400\":0.829}}','[\"SS400\"]','[\"25.4*1.4T\"]',1,'single',351,'25.4*1.4T',0.829),
(356,'structural-pipe','구조관 31.8*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"31.8*1.4T\":{\"SS400\":1.05}}','[\"SS400\"]','[\"31.8*1.4T\"]',1,'single',351,'31.8*1.4T',1.050),
(357,'structural-pipe','구조관 38.1*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"38.1*1.4T\":{\"SS400\":1.267}}','[\"SS400\"]','[\"38.1*1.4T\"]',1,'single',351,'38.1*1.4T',1.267),
(358,'structural-pipe','구조관 50.8*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"50.8*1.4T\":{\"SS400\":1.705}}','[\"SS400\"]','[\"50.8*1.4T\"]',1,'single',351,'50.8*1.4T',1.705),
(359,'structural-pipe','구조관 63.5*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"63.5*1.4T\":{\"SS400\":2.144}}','[\"SS400\"]','[\"63.5*1.4T\"]',1,'single',351,'63.5*1.4T',2.144),
(360,'structural-pipe','구조관 76.2*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"76.2*1.4T\":{\"SS400\":2.582}}','[\"SS400\"]','[\"76.2*1.4T\"]',1,'single',351,'76.2*1.4T',2.582),
(361,'structural-pipe','구조관 101.6*1.4T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"101.6*1.4T\":{\"SS400\":3.946}}','[\"SS400\"]','[\"101.6*1.4T\"]',1,'single',351,'101.6*1.4T',3.946),
(362,'structural-pipe','구조관 139.7*2.8T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"139.7*2.8T\":{\"SS400\":10.842}}','[\"SS400\"]','[\"139.7*2.8T\"]',1,'single',351,'139.7*2.8T',10.842),
(363,'structural-pipe','구조관 165.1*2.8T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"165.1*2.8T\":{\"SS400\":12.845}}','[\"SS400\"]','[\"165.1*2.8T\"]',1,'single',351,'165.1*2.8T',12.845),
(364,'structural-pipe','구조관 190.5*2.8T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"190.5*2.8T\":{\"SS400\":14.848}}','[\"SS400\"]','[\"190.5*2.8T\"]',1,'single',351,'190.5*2.8T',14.848),
(365,'structural-pipe','구조관 216.0*2.8T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"216.0*2.8T\":{\"SS400\":16.851}}','[\"SS400\"]','[\"216.0*2.8T\"]',1,'single',351,'216.0*2.8T',16.851),
(366,'structural-pipe','구조관 267.0*2.8T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"267.0*2.8T\":{\"SS400\":20.858}}','[\"SS400\"]','[\"267.0*2.8T\"]',1,'single',351,'267.0*2.8T',20.858),
(367,'steel-pipe-pile','강관파일',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"500*9T\":{\"SS400\":109},\"500*12T\":{\"SS400\":144},\"500*14T\":{\"SS400\":168},\"600*9T\":{\"SS400\":131},\"600*12T\":{\"SS400\":174},\"600*14T\":{\"SS400\":202},\"600*16T\":{\"SS400\":230},\"700*9T\":{\"SS400\":153},\"700*12T\":{\"SS400\":204},\"700*14T\":{\"SS400\":237},\"800*9T\":{\"SS400\":175},\"800*12T\":{\"SS400\":233},\"800*14T\":{\"SS400\":271},\"900*9T\":{\"SS400\":197},\"900*12T\":{\"SS400\":262}}','[\"SS400\"]','[\"500*9T\",\"500*12T\",\"500*14T\",\"600*9T\",\"600*12T\",\"600*14T\",\"600*16T\",\"700*9T\",\"700*12T\",\"700*14T\",\"800*9T\",\"800*12T\",\"800*14T\",\"900*9T\",\"900*12T\"]',1,'by_specification',NULL,NULL,NULL),
(368,'steel-pipe-pile','강관파일 500*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"500*9T\":{\"SS400\":109}}','[\"SS400\"]','[\"500*9T\"]',1,'single',367,'500*9T',109.000),
(369,'steel-pipe-pile','강관파일 500*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"500*12T\":{\"SS400\":144}}','[\"SS400\"]','[\"500*12T\"]',1,'single',367,'500*12T',144.000),
(370,'steel-pipe-pile','강관파일 500*14T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"500*14T\":{\"SS400\":168}}','[\"SS400\"]','[\"500*14T\"]',1,'single',367,'500*14T',168.000),
(371,'steel-pipe-pile','강관파일 600*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"600*9T\":{\"SS400\":131}}','[\"SS400\"]','[\"600*9T\"]',1,'single',367,'600*9T',131.000),
(372,'steel-pipe-pile','강관파일 600*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"600*12T\":{\"SS400\":174}}','[\"SS400\"]','[\"600*12T\"]',1,'single',367,'600*12T',174.000),
(373,'steel-pipe-pile','강관파일 600*14T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"600*14T\":{\"SS400\":202}}','[\"SS400\"]','[\"600*14T\"]',1,'single',367,'600*14T',202.000),
(374,'steel-pipe-pile','강관파일 600*16T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"600*16T\":{\"SS400\":230}}','[\"SS400\"]','[\"600*16T\"]',1,'single',367,'600*16T',230.000),
(375,'steel-pipe-pile','강관파일 700*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"700*9T\":{\"SS400\":153}}','[\"SS400\"]','[\"700*9T\"]',1,'single',367,'700*9T',153.000),
(376,'steel-pipe-pile','강관파일 700*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"700*12T\":{\"SS400\":204}}','[\"SS400\"]','[\"700*12T\"]',1,'single',367,'700*12T',204.000),
(377,'steel-pipe-pile','강관파일 700*14T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"700*14T\":{\"SS400\":237}}','[\"SS400\"]','[\"700*14T\"]',1,'single',367,'700*14T',237.000),
(378,'steel-pipe-pile','강관파일 800*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"800*9T\":{\"SS400\":175}}','[\"SS400\"]','[\"800*9T\"]',1,'single',367,'800*9T',175.000),
(379,'steel-pipe-pile','강관파일 800*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"800*12T\":{\"SS400\":233}}','[\"SS400\"]','[\"800*12T\"]',1,'single',367,'800*12T',233.000),
(380,'steel-pipe-pile','강관파일 800*14T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"800*14T\":{\"SS400\":271}}','[\"SS400\"]','[\"800*14T\"]',1,'single',367,'800*14T',271.000),
(381,'steel-pipe-pile','강관파일 900*9T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"900*9T\":{\"SS400\":197}}','[\"SS400\"]','[\"900*9T\"]',1,'single',367,'900*9T',197.000),
(382,'steel-pipe-pile','강관파일 900*12T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','linear','{\"900*12T\":{\"SS400\":262}}','[\"SS400\"]','[\"900*12T\"]',1,'single',367,'900*12T',262.000),
(383,'deck-plate','데크플레이트 614*50*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:19','2025-08-31 13:36:37','sheet','{\"614*50*1.2T\":{\"SS400\":8.24}}','[\"SS400\"]','[\"614*50*1.2T\"]',1,'single',181,'614*50*1.2T',8.240),
(384,'deck-plate','데크플레이트 614*50*1.2T(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"614*50*1.2T(GI)\":{\"SS400\":8.58}}','[\"SS400\"]','[\"614*50*1.2T(GI)\"]',1,'single',181,'614*50*1.2T(GI)',8.580),
(385,'deck-plate','데크플레이트 614*50*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"614*50*1.6T\":{\"SS400\":10.99}}','[\"SS400\"]','[\"614*50*1.6T\"]',1,'single',181,'614*50*1.6T',10.990),
(386,'deck-plate','데크플레이트 614*50*1.6(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"614*50*1.6(GI)\":{\"SS400\":11.32}}','[\"SS400\"]','[\"614*50*1.6(GI)\"]',1,'single',181,'614*50*1.6(GI)',11.320),
(387,'deck-plate','데크플레이트 660*50*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"660*50*1.2T\":{\"SS400\":8.61}}','[\"SS400\"]','[\"660*50*1.2T\"]',1,'single',181,'660*50*1.2T',8.610),
(388,'deck-plate','데크플레이트 660*50*1.2T(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"660*50*1.2T(GI)\":{\"SS400\":8.96}}','[\"SS400\"]','[\"660*50*1.2T(GI)\"]',1,'single',181,'660*50*1.2T(GI)',8.960),
(389,'deck-plate','데크플레이트 660*50*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"660*50*1.6T\":{\"SS400\":11.48}}','[\"SS400\"]','[\"660*50*1.6T\"]',1,'single',181,'660*50*1.6T',11.480),
(390,'deck-plate','데크플레이트 660*50*1.6T(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"660*50*1.6T(GI)\":{\"SS400\":11.83}}','[\"SS400\"]','[\"660*50*1.6T(GI)\"]',1,'single',181,'660*50*1.6T(GI)',11.830),
(391,'deck-plate','데크플레이트 600*75*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*75*1.2T\":{\"SS400\":9.38}}','[\"SS400\"]','[\"600*75*1.2T\"]',1,'single',181,'600*75*1.2T',9.380),
(392,'deck-plate','데크플레이트 600*75*1.2(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*75*1.2(GI)\":{\"SS400\":9.76}}','[\"SS400\"]','[\"600*75*1.2(GI)\"]',1,'single',181,'600*75*1.2(GI)',9.760),
(393,'deck-plate','데크플레이트 600*75*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*75*1.6T\":{\"SS400\":12.5}}','[\"SS400\"]','[\"600*75*1.6T\"]',1,'single',181,'600*75*1.6T',12.500),
(394,'deck-plate','데크플레이트 600*75*1.6T(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*75*1.6T(GI)\":{\"SS400\":12.9}}','[\"SS400\"]','[\"600*75*1.6T(GI)\"]',1,'single',181,'600*75*1.6T(GI)',12.900),
(395,'deck-plate','데크플레이트 600*100*1.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*100*1.2T\":{\"SS400\":10.83}}','[\"SS400\"]','[\"600*100*1.2T\"]',1,'single',181,'600*100*1.2T',10.830),
(396,'deck-plate','데크플레이트 600*100*1.2T(GI)',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*100*1.2T(GI)\":{\"SS400\":11.21}}','[\"SS400\"]','[\"600*100*1.2T(GI)\"]',1,'single',181,'600*100*1.2T(GI)',11.210),
(397,'deck-plate','데크플레이트 600*100*1.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"600*100*1.6T\":{\"SS400\":14.44}}','[\"SS400\"]','[\"600*100*1.6T\"]',1,'single',181,'600*100*1.6T',14.440),
(398,'rail','레일 9kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"9kg\":{\"SS400\":8.94}}','[\"SS400\"]','[\"9kg\"]',1,'single',210,'9kg',8.940),
(399,'rail','레일 15kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"15kg\":{\"SS400\":15.2}}','[\"SS400\"]','[\"15kg\"]',1,'single',210,'15kg',15.200),
(400,'rail','레일 22kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"22kg\":{\"SS400\":22.3}}','[\"SS400\"]','[\"22kg\"]',1,'single',210,'22kg',22.300),
(401,'rail','레일 30kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"30kg\":{\"SS400\":30.1}}','[\"SS400\"]','[\"30kg\"]',1,'single',210,'30kg',30.100),
(402,'rail','레일 37kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"37kg\":{\"SS400\":37.2}}','[\"SS400\"]','[\"37kg\"]',1,'single',210,'37kg',37.200),
(403,'rail','레일 50kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"50kg\":{\"SS400\":50.4}}','[\"SS400\"]','[\"50kg\"]',1,'single',210,'50kg',50.400),
(404,'rail','레일 50kg/N',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"50kg\\/N\":{\"SS400\":50.4}}','[\"SS400\"]','[\"50kg\\/N\"]',1,'single',210,'50kg/N',50.400),
(405,'rail','레일 60kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"60kg\":{\"SS400\":60.8}}','[\"SS400\"]','[\"60kg\"]',1,'single',210,'60kg',60.800),
(406,'rail','레일 70kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"70kg\":{\"SS400\":69.5}}','[\"SS400\"]','[\"70kg\"]',1,'single',210,'70kg',69.500),
(407,'rail','레일 73kg',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"73kg\":{\"SS400\":73.3}}','[\"SS400\"]','[\"73kg\"]',1,'single',210,'73kg',73.300),
(408,'temporary-deck','복공판 1,990X750X200',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','sheet','{\"1,990X750X200\":{\"SS400\":280}}','[\"SS400\"]','[\"1,990X750X200\"]',1,'single',197,'1,990X750X200',280.000),
(409,'sheet-pile','쉬트파일',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*75*8.0T\":{\"SS400\":36.5},\"400*80*7.6T\":{\"SS400\":35.5},\"400*85*8.0T\":{\"SS400\":35.5},\"400*100*10.5T\":{\"SS400\":48},\"400*110*9.3T\":{\"SS400\":43.2},\"400*120*9.2T\":{\"SS400\":43.2},\"400*125*13.0T\":{\"SS400\":60},\"400*150*13.1T\":{\"SS400\":58.4},\"400*170*15.5T\":{\"SS400\":76.1},\"400*170*17.3T\":{\"SS400\":80},\"500*200*24.3T\":{\"SS400\":106},\"500*225*27.6T\":{\"SS400\":126},\"600*180*21.5T\":{\"SS400\":106},\"600*210*18.0T\":{\"SS400\":120},\"600*225*27.6T\":{\"SS400\":151}}','[\"SS400\"]','[\"400*75*8.0T\",\"400*80*7.6T\",\"400*85*8.0T\",\"400*100*10.5T\",\"400*110*9.3T\",\"400*120*9.2T\",\"400*125*13.0T\",\"400*150*13.1T\",\"400*170*15.5T\",\"400*170*17.3T\",\"500*200*24.3T\",\"500*225*27.6T\",\"600*180*21.5T\",\"600*210*18.0T\",\"600*225*27.6T\"]',1,'by_specification',NULL,NULL,NULL),
(410,'sheet-pile','쉬트파일 400*75*8.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*75*8.0T\":{\"SS400\":36.5}}','[\"SS400\"]','[\"400*75*8.0T\"]',1,'single',409,'400*75*8.0T',36.500),
(411,'sheet-pile','쉬트파일 400*80*7.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*80*7.6T\":{\"SS400\":35.5}}','[\"SS400\"]','[\"400*80*7.6T\"]',1,'single',409,'400*80*7.6T',35.500),
(412,'sheet-pile','쉬트파일 400*85*8.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*85*8.0T\":{\"SS400\":35.5}}','[\"SS400\"]','[\"400*85*8.0T\"]',1,'single',409,'400*85*8.0T',35.500),
(413,'sheet-pile','쉬트파일 400*100*10.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*100*10.5T\":{\"SS400\":48}}','[\"SS400\"]','[\"400*100*10.5T\"]',1,'single',409,'400*100*10.5T',48.000),
(414,'sheet-pile','쉬트파일 400*110*9.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*110*9.3T\":{\"SS400\":43.2}}','[\"SS400\"]','[\"400*110*9.3T\"]',1,'single',409,'400*110*9.3T',43.200),
(415,'sheet-pile','쉬트파일 400*120*9.2T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*120*9.2T\":{\"SS400\":43.2}}','[\"SS400\"]','[\"400*120*9.2T\"]',1,'single',409,'400*120*9.2T',43.200),
(416,'sheet-pile','쉬트파일 400*125*13.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*125*13.0T\":{\"SS400\":60}}','[\"SS400\"]','[\"400*125*13.0T\"]',1,'single',409,'400*125*13.0T',60.000),
(417,'sheet-pile','쉬트파일 400*150*13.1T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*150*13.1T\":{\"SS400\":58.4}}','[\"SS400\"]','[\"400*150*13.1T\"]',1,'single',409,'400*150*13.1T',58.400),
(418,'sheet-pile','쉬트파일 400*170*15.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*170*15.5T\":{\"SS400\":76.1}}','[\"SS400\"]','[\"400*170*15.5T\"]',1,'single',409,'400*170*15.5T',76.100),
(419,'sheet-pile','쉬트파일 400*170*17.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"400*170*17.3T\":{\"SS400\":80}}','[\"SS400\"]','[\"400*170*17.3T\"]',1,'single',409,'400*170*17.3T',80.000),
(420,'sheet-pile','쉬트파일 500*200*24.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"500*200*24.3T\":{\"SS400\":106}}','[\"SS400\"]','[\"500*200*24.3T\"]',1,'single',409,'500*200*24.3T',106.000),
(421,'sheet-pile','쉬트파일 500*225*27.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"500*225*27.6T\":{\"SS400\":126}}','[\"SS400\"]','[\"500*225*27.6T\"]',1,'single',409,'500*225*27.6T',126.000),
(422,'sheet-pile','쉬트파일 600*180*21.5T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"600*180*21.5T\":{\"SS400\":106}}','[\"SS400\"]','[\"600*180*21.5T\"]',1,'single',409,'600*180*21.5T',106.000),
(423,'sheet-pile','쉬트파일 600*210*18.0T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"600*210*18.0T\":{\"SS400\":120}}','[\"SS400\"]','[\"600*210*18.0T\"]',1,'single',409,'600*210*18.0T',120.000),
(424,'sheet-pile','쉬트파일 600*225*27.6T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock','/uploads/products/424_1756646666.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"600*225*27.6T\":{\"SS400\":151}}','[\"SS400\"]','[\"600*225*27.6T\"]',1,'single',409,'600*225*27.6T',151.000),
(425,'pressure-pipe','압력배관',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"15A\":{\"SS400\":1.22},\"20A\":{\"SS400\":1.63},\"25A\":{\"SS400\":2.43},\"32A\":{\"SS400\":3.25},\"40A\":{\"SS400\":3.83},\"50A\":{\"SS400\":5.2},\"65A\":{\"SS400\":8.55},\"80A\":{\"SS400\":10.67},\"90A\":{\"SS400\":12.58},\"100A\":{\"SS400\":14.98},\"125A\":{\"SS400\":22.71},\"150A\":{\"SS400\":30.11},\"200A\":{\"SS400\":50.81},\"250A\":{\"SS400\":77.35},\"300A\":{\"SS400\":104.7}}','[\"SS400\"]','[\"15A\",\"20A\",\"25A\",\"32A\",\"40A\",\"50A\",\"65A\",\"80A\",\"90A\",\"100A\",\"125A\",\"150A\",\"200A\",\"250A\",\"300A\"]',1,'by_specification',NULL,NULL,NULL),
(426,'pressure-pipe','압력배관 15A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"15A\":{\"SS400\":1.22}}','[\"SS400\"]','[\"15A\"]',1,'single',425,'15A',1.220),
(427,'pressure-pipe','압력배관 20A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"20A\":{\"SS400\":1.63}}','[\"SS400\"]','[\"20A\"]',1,'single',425,'20A',1.630),
(428,'pressure-pipe','압력배관 25A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"25A\":{\"SS400\":2.43}}','[\"SS400\"]','[\"25A\"]',1,'single',425,'25A',2.430),
(429,'pressure-pipe','압력배관 32A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"32A\":{\"SS400\":3.25}}','[\"SS400\"]','[\"32A\"]',1,'single',425,'32A',3.250),
(430,'pressure-pipe','압력배관 40A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"40A\":{\"SS400\":3.83}}','[\"SS400\"]','[\"40A\"]',1,'single',425,'40A',3.830),
(431,'pressure-pipe','압력배관 50A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"50A\":{\"SS400\":5.2}}','[\"SS400\"]','[\"50A\"]',1,'single',425,'50A',5.200),
(432,'pressure-pipe','압력배관 65A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"65A\":{\"SS400\":8.55}}','[\"SS400\"]','[\"65A\"]',1,'single',425,'65A',8.550),
(433,'pressure-pipe','압력배관 80A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"80A\":{\"SS400\":10.67}}','[\"SS400\"]','[\"80A\"]',1,'single',425,'80A',10.670),
(434,'pressure-pipe','압력배관 90A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"90A\":{\"SS400\":12.58}}','[\"SS400\"]','[\"90A\"]',1,'single',425,'90A',12.580),
(435,'pressure-pipe','압력배관 100A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"100A\":{\"SS400\":14.98}}','[\"SS400\"]','[\"100A\"]',1,'single',425,'100A',14.980),
(436,'pressure-pipe','압력배관 125A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"125A\":{\"SS400\":22.71}}','[\"SS400\"]','[\"125A\"]',1,'single',425,'125A',22.710),
(437,'pressure-pipe','압력배관 150A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"150A\":{\"SS400\":30.11}}','[\"SS400\"]','[\"150A\"]',1,'single',425,'150A',30.110),
(438,'pressure-pipe','압력배관 200A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"200A\":{\"SS400\":50.81}}','[\"SS400\"]','[\"200A\"]',1,'single',425,'200A',50.810),
(439,'pressure-pipe','압력배관 250A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"250A\":{\"SS400\":77.35}}','[\"SS400\"]','[\"250A\"]',1,'single',425,'250A',77.350),
(440,'pressure-pipe','압력배관 300A',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"300A\":{\"SS400\":104.7}}','[\"SS400\"]','[\"300A\"]',1,'single',425,'300A',104.700),
(441,'conduit-pipe','전선관',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"16BC\":{\"SS400\":0.63},\"22BC\":{\"SS400\":0.82},\"28BC\":{\"SS400\":1.13},\"36BC\":{\"SS400\":1.47},\"42BC\":{\"SS400\":1.67},\"54BC\":{\"SS400\":2.35},\"70BC\":{\"SS400\":3},\"82BC\":{\"SS400\":3.53},\"104BC\":{\"SS400\":5.68}}','[\"SS400\"]','[\"16BC\",\"22BC\",\"28BC\",\"36BC\",\"42BC\",\"54BC\",\"70BC\",\"82BC\",\"104BC\"]',1,'by_specification',NULL,NULL,NULL),
(442,'conduit-pipe','전선관 16BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"16BC\":{\"SS400\":0.63}}','[\"SS400\"]','[\"16BC\"]',1,'single',441,'16BC',0.630),
(443,'conduit-pipe','전선관 22BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"22BC\":{\"SS400\":0.82}}','[\"SS400\"]','[\"22BC\"]',1,'single',441,'22BC',0.820),
(444,'conduit-pipe','전선관 28BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"28BC\":{\"SS400\":1.13}}','[\"SS400\"]','[\"28BC\"]',1,'single',441,'28BC',1.130),
(445,'conduit-pipe','전선관 36BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:20','2025-08-31 13:36:37','linear','{\"36BC\":{\"SS400\":1.47}}','[\"SS400\"]','[\"36BC\"]',1,'single',441,'36BC',1.470),
(446,'conduit-pipe','전선관 42BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"42BC\":{\"SS400\":1.67}}','[\"SS400\"]','[\"42BC\"]',1,'single',441,'42BC',1.670),
(447,'conduit-pipe','전선관 54BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"54BC\":{\"SS400\":2.35}}','[\"SS400\"]','[\"54BC\"]',1,'single',441,'54BC',2.350),
(448,'conduit-pipe','전선관 70BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"70BC\":{\"SS400\":3}}','[\"SS400\"]','[\"70BC\"]',1,'single',441,'70BC',3.000),
(449,'conduit-pipe','전선관 82BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"82BC\":{\"SS400\":3.53}}','[\"SS400\"]','[\"82BC\"]',1,'single',441,'82BC',3.530),
(450,'conduit-pipe','전선관 104BC',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"104BC\":{\"SS400\":5.68}}','[\"SS400\"]','[\"104BC\"]',1,'single',441,'104BC',5.680),
(451,'scaffold-pipe','단관비계',NULL,'123','',NULL,'',1,'in_stock',NULL,NULL,'','','','','','','[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','',NULL,NULL,0,1,3,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"48.6T*2.3T\":{\"SS400\":2.626}}','[\"SS400\"]','[\"48.6T*2.3T\"]',1,'by_specification',NULL,NULL,NULL),
(452,'scaffold-pipe','단관비계 48.6T*2.3T',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"48.6T*2.3T\":{\"SS400\":2.626}}','[\"SS400\"]','[\"48.6T*2.3T\"]',1,'single',451,'48.6T*2.3T',2.626),
(453,'i-beam','I형강 100*75*5*8',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"100*75*5*8\":{\"SS400\":13.9}}','[\"SS400\"]','[\"100*75*5*8\"]',1,'single',166,'100*75*5*8',13.900),
(454,'i-beam','I형강 125*75*5.5*9.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"125*75*5.5*9.5\":{\"SS400\":16.1}}','[\"SS400\"]','[\"125*75*5.5*9.5\"]',1,'single',166,'125*75*5.5*9.5',16.100),
(455,'i-beam','I형강 150*75*5.5*9.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"150*75*5.5*9.5\":{\"SS400\":17.1}}','[\"SS400\"]','[\"150*75*5.5*9.5\"]',1,'single',166,'150*75*5.5*9.5',17.100),
(456,'i-beam','I형강 150*125*8.5*14',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"150*125*8.5*14\":{\"SS400\":36.2}}','[\"SS400\"]','[\"150*125*8.5*14\"]',1,'single',166,'150*125*8.5*14',36.200),
(457,'i-beam','I형강 180*100*6*10',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"180*100*6*10\":{\"SS400\":23.6}}','[\"SS400\"]','[\"180*100*6*10\"]',1,'single',166,'180*100*6*10',23.600),
(458,'i-beam','I형강 200*100*70*10',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"200*100*70*10\":{\"SS400\":26}}','[\"SS400\"]','[\"200*100*70*10\"]',1,'single',166,'200*100*70*10',26.000),
(459,'i-beam','I형강 200*150*9*16',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"200*150*9*16\":{\"SS400\":50.4}}','[\"SS400\"]','[\"200*150*9*16\"]',1,'single',166,'200*150*9*16',50.400),
(460,'i-beam','I형강 250*125*7.5*12.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"250*125*7.5*12.5\":{\"SS400\":38.3}}','[\"SS400\"]','[\"250*125*7.5*12.5\"]',1,'single',166,'250*125*7.5*12.5',38.300),
(461,'i-beam','I형강 250*125*10*19',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"250*125*10*19\":{\"SS400\":55.5}}','[\"SS400\"]','[\"250*125*10*19\"]',1,'single',166,'250*125*10*19',55.500),
(462,'i-beam','I형강 300*150*8*13',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"300*150*8*13\":{\"SS400\":48.3}}','[\"SS400\"]','[\"300*150*8*13\"]',1,'single',166,'300*150*8*13',48.300),
(463,'i-beam','I형강 300*150*10.5*16.5',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"300*150*10.5*16.5\":{\"SS400\":62.5}}','[\"SS400\"]','[\"300*150*10.5*16.5\"]',1,'single',166,'300*150*10.5*16.5',62.500),
(464,'i-beam','I형강 350*175*10*16',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"350*175*10*16\":{\"SS400\":75}}','[\"SS400\"]','[\"350*175*10*16\"]',1,'single',166,'350*175*10*16',75.000),
(465,'i-beam','I형강 400*200*10*16',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"400*200*10*16\":{\"SS400\":83.3}}','[\"SS400\"]','[\"400*200*10*16\"]',1,'single',166,'400*200*10*16',83.300),
(466,'i-beam','I형강 450*200*11*18',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"450*200*11*18\":{\"SS400\":101}}','[\"SS400\"]','[\"450*200*11*18\"]',1,'single',166,'450*200*11*18',101.000),
(467,'i-beam','I형강 500*200*11.5*19',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"500*200*11.5*19\":{\"SS400\":113}}','[\"SS400\"]','[\"500*200*11.5*19\"]',1,'single',166,'500*200*11.5*19',113.000),
(468,'i-beam','I형강 600*220*12*20',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"600*220*12*20\":{\"SS400\":133}}','[\"SS400\"]','[\"600*220*12*20\"]',1,'single',166,'600*220*12*20',133.000),
(469,'i-beam','I형강 700*250*13*24',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,0,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"700*250*13*24\":{\"SS400\":183}}','[\"SS400\"]','[\"700*250*13*24\"]',1,'single',166,'700*250*13*24',183.000),
(470,'i-beam','I형강 800*280*14*26',NULL,'800*280*14*26','./114/cnst_banner_800pix.gif\r\n/uploads/products/20250831125822_68b446ee94adf.jpeg',NULL,'',1,'in_stock',NULL,NULL,'','','','','','','[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]','',NULL,NULL,0,1,5,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"800*280*14*26\":{\"SS400\":219}}','[\"SS400\"]','[\"800*280*14*26\"]',1,'single',166,'800*280*14*26',219.000),
(471,'i-beam','I형강 900*300*16*28',NULL,NULL,'./114/cnst_banner_800pix.gif',NULL,NULL,1,'in_stock',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'[\"국산\",\"중국산\",\"일본산\",\"베트남산\",\"바레이산\",\"수입산\",\"쟁가재고\",\"중고\"]',NULL,NULL,NULL,0,1,1,'2025-08-31 10:55:21','2025-08-31 13:36:37','linear','{\"900*300*16*28\":{\"SS400\":258}}','[\"SS400\"]','[\"900*300*16*28\"]',1,'single',166,'900*300*16*28',258.000);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_length_data`
--

DROP TABLE IF EXISTS `rebar_length_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_length_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_name` varchar(50) NOT NULL,
  `length` decimal(5,1) NOT NULL,
  `piece_weight` decimal(10,3) DEFAULT NULL,
  `pieces_per_ton` int(11) DEFAULT NULL,
  `weight_per_ton` decimal(10,1) DEFAULT NULL,
  `unit_weight` decimal(10,3) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_spec_length` (`spec_name`,`length`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_length_data`
--

LOCK TABLES `rebar_length_data` WRITE;
/*!40000 ALTER TABLE `rebar_length_data` DISABLE KEYS */;
INSERT INTO `rebar_length_data` VALUES
(1,'D10',6.0,NULL,300,1008.0,0.560,'2025-08-05 02:47:30'),
(2,'D10',7.0,NULL,270,1058.0,0.560,'2025-08-05 02:47:30'),
(3,'D10',8.0,NULL,210,941.0,0.560,'2025-08-05 02:47:30'),
(4,'D13',6.0,NULL,168,1004.0,0.995,'2025-08-05 02:47:30'),
(5,'D13',7.0,NULL,144,1004.0,0.995,'2025-08-05 02:47:30'),
(6,'D13',8.0,NULL,126,1004.0,0.995,'2025-08-05 02:47:30');
/*!40000 ALTER TABLE `rebar_length_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_length_info`
--

DROP TABLE IF EXISTS `rebar_length_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_length_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) NOT NULL,
  `length` decimal(5,1) NOT NULL,
  `pieces_per_ton` int(11) NOT NULL,
  `total_weight` decimal(10,1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_spec_length` (`spec_id`,`length`),
  KEY `idx_rebar_length_spec` (`spec_id`),
  CONSTRAINT `rebar_length_info_ibfk_1` FOREIGN KEY (`spec_id`) REFERENCES `rebar_specifications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_length_info`
--

LOCK TABLES `rebar_length_info` WRITE;
/*!40000 ALTER TABLE `rebar_length_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `rebar_length_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_materials`
--

DROP TABLE IF EXISTS `rebar_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `display_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_name` (`material_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_materials`
--

LOCK TABLES `rebar_materials` WRITE;
/*!40000 ALTER TABLE `rebar_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `rebar_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_prices`
--

DROP TABLE IF EXISTS `rebar_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_name` varchar(50) NOT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `price_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_spec_origin` (`spec_name`,`origin`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_prices`
--

LOCK TABLES `rebar_prices` WRITE;
/*!40000 ALTER TABLE `rebar_prices` DISABLE KEYS */;
INSERT INTO `rebar_prices` VALUES
(1,'D10','포항','현대제철',850000.00,'2025-08-05',1,'2025-08-05 02:44:08','2025-08-05 02:44:08'),
(2,'D13','포항','현대제철',830000.00,'2025-08-05',1,'2025-08-05 02:44:08','2025-08-05 02:44:08'),
(3,'D16','포항','현대제철',820000.00,'2025-08-05',1,'2025-08-05 02:44:08','2025-08-05 02:44:08');
/*!40000 ALTER TABLE `rebar_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_products`
--

DROP TABLE IF EXISTS `rebar_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `stock_status` varchar(50) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `available_origins` text DEFAULT NULL,
  `stock_types` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `spec_id` (`spec_id`),
  KEY `material_id` (`material_id`),
  CONSTRAINT `rebar_products_ibfk_1` FOREIGN KEY (`spec_id`) REFERENCES `rebar_specifications` (`id`),
  CONSTRAINT `rebar_products_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `rebar_materials` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_products`
--

LOCK TABLES `rebar_products` WRITE;
/*!40000 ALTER TABLE `rebar_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `rebar_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_quote_items`
--

DROP TABLE IF EXISTS `rebar_quote_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL COMMENT '견적 ID',
  `spec_id` int(11) NOT NULL COMMENT '철근 규격 ID',
  `length` decimal(5,1) NOT NULL COMMENT '선택 길이(m)',
  `quantity` int(11) NOT NULL COMMENT '수량(본수)',
  `unit_weight` decimal(10,3) NOT NULL COMMENT '단위중량(kg/m) - 계산용',
  `unit_price` decimal(12,2) NOT NULL COMMENT '단가(원/kg)',
  `total_weight` decimal(15,2) NOT NULL COMMENT '총중량(kg) = 수량 × 길이 × 단위중량',
  `total_amount` decimal(15,2) NOT NULL COMMENT '총금액(원) = 총중량 × 단가',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `spec_id` (`spec_id`),
  KEY `idx_quote_id` (`quote_id`),
  CONSTRAINT `rebar_quote_items_ibfk_1` FOREIGN KEY (`quote_id`) REFERENCES `rebar_quotes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rebar_quote_items_ibfk_2` FOREIGN KEY (`spec_id`) REFERENCES `rebar_specifications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='철근 견적 상세 항목';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_quote_items`
--

LOCK TABLES `rebar_quote_items` WRITE;
/*!40000 ALTER TABLE `rebar_quote_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `rebar_quote_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_quotes`
--

DROP TABLE IF EXISTS `rebar_quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(50) NOT NULL COMMENT '견적번호',
  `member_id` int(11) DEFAULT NULL COMMENT '회원 ID',
  `customer_name` varchar(100) NOT NULL COMMENT '고객명',
  `customer_phone` varchar(20) DEFAULT NULL COMMENT '연락처',
  `customer_email` varchar(100) DEFAULT NULL COMMENT '이메일',
  `company_name` varchar(200) DEFAULT NULL COMMENT '회사명',
  `total_amount` decimal(15,2) NOT NULL COMMENT '총 금액',
  `status` enum('pending','confirmed','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL COMMENT '비고',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `quote_number` (`quote_number`),
  KEY `idx_quote_number` (`quote_number`),
  KEY `idx_member_id` (`member_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='철근 견적서';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_quotes`
--

LOCK TABLES `rebar_quotes` WRITE;
/*!40000 ALTER TABLE `rebar_quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `rebar_quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rebar_specifications`
--

DROP TABLE IF EXISTS `rebar_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rebar_specifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_name` varchar(50) NOT NULL,
  `diameter` decimal(5,1) NOT NULL,
  `weight_per_meter` decimal(10,3) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `spec_name` (`spec_name`),
  KEY `idx_rebar_spec_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rebar_specifications`
--

LOCK TABLES `rebar_specifications` WRITE;
/*!40000 ALTER TABLE `rebar_specifications` DISABLE KEYS */;
INSERT INTO `rebar_specifications` VALUES
(1,'D10',10.0,0.560,'2025-08-05 02:40:29',1),
(2,'D13',12.7,0.995,'2025-08-05 02:40:29',1),
(3,'D16',15.9,1.560,'2025-08-05 02:40:29',1),
(4,'D19',19.1,2.250,'2025-08-05 02:40:29',1),
(5,'D22',22.2,3.040,'2025-08-05 02:40:29',1),
(6,'D25',25.4,3.980,'2025-08-05 02:40:29',1),
(7,'D29',28.6,5.040,'2025-08-05 02:40:29',1),
(8,'D32',31.8,6.230,'2025-08-05 02:40:29',1),
(9,'D35',34.9,7.510,'2025-08-05 02:40:29',1),
(10,'D38',38.1,8.950,'2025-08-05 02:40:29',1),
(11,'D41',41.3,10.500,'2025-08-05 02:40:29',1),
(12,'D51',50.8,15.900,'2025-08-05 02:40:29',1);
/*!40000 ALTER TABLE `rebar_specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(50) DEFAULT 'text',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_weights`
--

DROP TABLE IF EXISTS `unit_weights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit_weights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(50) NOT NULL COMMENT '제품유형',
  `specification` varchar(100) NOT NULL COMMENT '규격',
  `unit_weight` decimal(10,2) NOT NULL COMMENT '단위중량',
  `material` varchar(50) DEFAULT NULL COMMENT '재질',
  `height` int(11) DEFAULT NULL COMMENT '높이',
  `width` int(11) DEFAULT NULL COMMENT '너비',
  `web_thickness` decimal(5,1) DEFAULT NULL COMMENT '웹두께',
  `flange_thickness` decimal(5,1) DEFAULT NULL COMMENT '플랜지두께',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_spec` (`product_type`,`specification`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_weights`
--

LOCK TABLES `unit_weights` WRITE;
/*!40000 ALTER TABLE `unit_weights` DISABLE KEYS */;
INSERT INTO `unit_weights` VALUES
(1,'H형강','100×100×6×8',17.20,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(2,'H형강','125×125×6.5×9',23.80,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(3,'H형강','150×150×7×10',31.50,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(4,'H형강','200×200×8×12',50.50,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(5,'H형강','250×250×9×14',72.40,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(6,'경량H형강','100×50×5×7',9.30,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(7,'경량H형강','150×75×5×7',14.00,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29'),
(8,'경량H형강','200×100×5.5×8',21.30,NULL,NULL,NULL,NULL,NULL,1,'2025-08-05 02:40:29','2025-08-05 02:40:29');
/*!40000 ALTER TABLE `unit_weights` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-31 13:58:38
